import React, { useState, useEffect } from 'react';
import Input from '../common/Input';
import Select from '../common/Select';
import Button from '../common/Button';
import { validators, validateForm } from '../../utils/validators';
import productService from '../../services/productService';
import companyService from '../../services/companyService';
import warehouseService from '../../services/warehouseService';
import { useNotification } from '../../context/NotificationContext';

function convertProductTypes(apiData) { 
  return apiData.map(item => ({
    value: String(item.id),
    label: item.name
  }));
}

const ProductForm = ({ product = null, onSubmit, onCancel }) => {
  const [formData, setFormData] = useState({
    name: product?.name || '',
    sku: product?.sku || '',
    product_type_id: parseInt(product?.product_type_id) || '',
    company_id: parseInt(product?.company_id) || '',
    hsn_code: product?.hsn_code || '',
    tax_rate: parseInt(product?.tax_rate) || 0,
    min_price: parseInt(product?.min_price) || '',
    max_price: parseInt(product?.max_price) || '',
    stock: product?.stock || 0,
    warehouse_id: parseInt(product?.warehouse_id) || '',
    is_active: product?.is_active ?? true
  });
  const [productTypes, setProductTypes] = useState([]);
  const { success, error } = useNotification();
  const [errors, setErrors] = useState({});
  const [loading, setLoading] = useState(false);
  const [companies, setCompanies] = useState([]);
  const [warehouses, setWarehouses] = useState([]); 

  const handleChange = (e) => {
    const { name, value, type, checked } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: type === 'checkbox' ? checked : value
    }));

    // Clear error for this field
    if (errors[name]) {
      setErrors(prev => ({ ...prev, [name]: '' }));
    }
  };

  const handleChange2 = (e) => {
    const { name, value, type, checked } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: type === 'checkbox' ? checked : parseInt(value)
    }));

    // Clear error for this field
    if (errors[name]) {
      setErrors(prev => ({ ...prev, [name]: '' }));
    }
  };

  const validate = () => {
    const rules = {
      name: [(v) => validators.required(v, 'Product name')],
      sku: [validators.sku],
      product_type_id: [(v) => validators.required(v, 'Product type')],
      company_id: [(v) => validators.required(v, 'Company')],
      min_price: [
        (v) => validators.number(v, 'Minimum price'),
        (v) => validators.min(v, 0, 'Minimum price')
      ],
      max_price: [
        (v) => validators.number(v, 'Maximum price'),
        (v) => validators.min(v, 0, 'Maximum price')
      ]
    };

    const { isValid, errors: validationErrors } = validateForm(formData, rules);

    // Additional validation for price range
    if (formData.min_price && formData.max_price) {
      if (Number(formData.min_price) >= Number(formData.max_price)) {
        validationErrors.max_price = 'Maximum price must be greater than minimum price';
      }
    }

    setErrors(validationErrors);
    return Object.keys(validationErrors).length === 0;
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    if (!validate()) return;

    setLoading(true);

    let dataToSubmit = {}

      if(product?.id){ 
        dataToSubmit = { 
          ...formData, 
          id: product?.id || null 
        };
      }else{
        dataToSubmit = { ...formData };
      }

    try {
      await onSubmit(dataToSubmit);
    } catch (error) {
      console.error('Form submission error:', error);
    } finally {
      setLoading(false);
    }
  };

  // let productTypes = {}; 

  useEffect(() => { 
    fetchPro() 
  }, []);

  const fetchPro = async () => {
    try { 
      const [companyResponse, fetchedProductsType, warehousesResponse] = await Promise.all([
          companyService.getAllCompanies(),  
          productService.getProductTypes(),
          warehouseService.getAllWarehouses()
      ])
      setProductTypes(() => convertProductTypes(fetchedProductsType.data))
      setCompanies(() => convertProductTypes(companyResponse.data)) 
      setWarehouses(() => convertProductTypes(warehousesResponse.data)) 

    } catch (err) {
      error('Failed to load products type');
    }
  } 
 

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <Input
          label="Product Name"
          name="name"
          value={formData.name}
          onChange={handleChange}
          placeholder="Enter product name"
          error={errors.name}
          required
        />

        <Input
          label="SKU"
          name="sku"
          value={formData.sku}
          onChange={handleChange}
          placeholder="e.g., IP14P-256-BL"
          error={errors.sku}
          required
        />

        <Select
          label="Product Type"
          name="product_type_id"
          value={formData.product_type_id}
          onChange={handleChange2}
          options={productTypes}
          error={errors.product_type_id}
          required
        />

        <Select
          label="Company"
          name="company_id"
          value={formData.company_id}
          onChange={handleChange2}
          options={companies}
          error={errors.company_id}
          required
        />

        <Input
          label="HSN Code"
          name="hsn_code"
          value={formData.hsn_code}
          onChange={handleChange}
          placeholder="e.g., 8517"
        />

        <Input
          label="Tax Rate (%)"
          name="tax_rate"
          type="number"
          value={formData.tax_rate}
          onChange={handleChange2}
          placeholder="18"
        />

        <Input
          label="Minimum Price (₹)"
          name="min_price"
          type="number"
          value={formData.min_price}
          onChange={handleChange2}
          placeholder="10000"
          error={errors.min_price}
          required
        />

        <Input
          label="Maximum Price (₹)"
          name="max_price"
          type="number"
          value={formData.max_price}
          onChange={handleChange2}
          placeholder="15000"
          error={errors.max_price}
          required
        />

        <Input
          label="Initial Stock"
          name="stock"
          type="number"
          value={formData.stock}
          onChange={handleChange2}
          placeholder="50"
        />

        <Select
          label="Warehouse"
          name="warehouse_id"
          value={formData.warehouse_id}
          onChange={handleChange2}
          options={warehouses}
          required
        />
      </div>

      <div className="pt-4">
        <label className="flex items-center space-x-2">
          <input
            type="checkbox"
            name="is_active"
            checked={formData.is_active}
            onChange={handleChange}
            className="rounded"
          />
          <span className="text-sm text-gray-700">Mark as active</span>
        </label>
      </div>

      <div className="flex justify-end space-x-3 pt-4 border-t">
        <Button type="button" variant="ghost" onClick={onCancel}>
          Cancel
        </Button>
        <Button type="submit" loading={loading}>
          {product ? 'Update Product' : 'Create Product'}
        </Button>
      </div>
    </form>
  );
};

export default ProductForm;