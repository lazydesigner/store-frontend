import React, { useState } from 'react';
import { Plus, Upload, Download, Edit, Trash2, Eye, Phone, Mail, MapPin } from 'lucide-react';
import Card from '../components/common/Card';
import Button from '../components/common/Button';
import Input from '../components/common/Input';
import Table from '../components/common/Table';
import Modal from '../components/common/Modal';
import SearchBar from '../components/common/SearchBar';
import Badge from '../components/common/Badge';

const Customers = () => {
  const [searchQuery, setSearchQuery] = useState('');
  const [showAddModal, setShowAddModal] = useState(false);
  const [selectedCustomer, setSelectedCustomer] = useState(null);

  const customers = [
    {
      id: 1,
      name: 'Rajesh Kumar',
      phone: '9876543210',
      email: 'rajesh@email.com',
      city: 'Mumbai',
      totalOrders: 15,
      totalSpent: 245000,
      lastOrder: '2025-10-28'
    },
    {
      id: 2,
      name: 'Priya Sharma',
      phone: '9876543211',
      email: 'priya@email.com',
      city: 'Delhi',
      totalOrders: 23,
      totalSpent: 389000,
      lastOrder: '2025-10-30'
    },
    {
      id: 3,
      name: 'Amit Patel',
      phone: '9876543212',
      email: 'amit@email.com',
      city: 'Ahmedabad',
      totalOrders: 8,
      totalSpent: 125000,
      lastOrder: '2025-10-25'
    }
  ];

  const columns = [
    {
      key: 'name',
      label: 'Customer Name',
      sortable: true,
      render: (value, row) => (
        <div>
          <p className="font-medium text-gray-900">{value}</p>
          <p className="text-xs text-gray-500 flex items-center mt-1">
            <Phone className="h-3 w-3 mr-1" />
            {row.phone}
          </p>
        </div>
      )
    },
    {
      key: 'email',
      label: 'Email',
      render: (value) => (
        <span className="text-sm text-gray-600 flex items-center">
          <Mail className="h-4 w-4 mr-1" />
          {value}
        </span>
      )
    },
    {
      key: 'city',
      label: 'City',
      sortable: true,
      render: (value) => (
        <span className="text-sm text-gray-600 flex items-center">
          <MapPin className="h-4 w-4 mr-1" />
          {value}
        </span>
      )
    },
    {
      key: 'totalOrders',
      label: 'Total Orders',
      sortable: true,
      render: (value) => <Badge variant="info">{value} orders</Badge>
    },
    {
      key: 'totalSpent',
      label: 'Total Spent',
      sortable: true,
      render: (value) => (
        <span className="font-semibold text-green-600">
          ₹{value.toLocaleString()}
        </span>
      )
    },
    {
      key: 'lastOrder',
      label: 'Last Order',
      render: (value) => (
        <span className="text-sm text-gray-500">{value}</span>
      )
    },
    {
      key: 'actions',
      label: 'Actions',
      render: (_, row) => (
        <div className="flex items-center space-x-2">
          <button 
            className="p-1 hover:bg-blue-50 rounded text-blue-600"
            onClick={() => setSelectedCustomer(row)}
            title="View"
          >
            <Eye className="h-4 w-4" />
          </button>
          <button className="p-1 hover:bg-yellow-50 rounded text-yellow-600" title="Edit">
            <Edit className="h-4 w-4" />
          </button>
          <button className="p-1 hover:bg-red-50 rounded text-red-600" title="Delete">
            <Trash2 className="h-4 w-4" />
          </button>
        </div>
      )
    }
  ];

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Customers</h1>
          <p className="text-gray-500 mt-1">Manage your customer database</p>
        </div>
        <div className="flex items-center space-x-3">
          <Button variant="outline" icon={Upload}>
            Import
          </Button>
          <Button variant="outline" icon={Download}>
            Export
          </Button>
          <Button icon={Plus} onClick={() => setShowAddModal(true)}>
            Add Customer
          </Button>
        </div>
      </div>

      {/* Search */}
      <Card>
        <SearchBar
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          onClear={() => setSearchQuery('')}
          placeholder="Search by name, phone or email..."
          className="mb-0"
        />
      </Card>

      {/* Table */}
      <Card>
        <Table columns={columns} data={customers} hover={true} />
      </Card>

      {/* Add/Edit Modal */}
      <Modal
        isOpen={showAddModal}
        onClose={() => setShowAddModal(false)}
        title="Add New Customer"
        size="lg"
        footer={
          <>
            <Button variant="ghost" onClick={() => setShowAddModal(false)}>
              Cancel
            </Button>
            <Button>Save Customer</Button>
          </>
        }
      >
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <Input label="Full Name" placeholder="Enter full name" required />
          <Input label="Phone Number" placeholder="10-digit mobile number" required />
          <Input label="Email" type="email" placeholder="customer@email.com" />
          <Input label="GSTIN" placeholder="GST Number (Optional)" />
        </div>
        
        <h3 className="text-lg font-semibold text-gray-900 mt-6 mb-4">Billing Address</h3>
        <div className="grid grid-cols-1 gap-4">
          <Input label="Address Line" placeholder="Street, Building, Area" />
          <div className="grid grid-cols-2 gap-4">
            <Input label="City" placeholder="City" />
            <Input label="State" placeholder="State" />
          </div>
          <div className="grid grid-cols-2 gap-4">
            <Input label="PIN Code" placeholder="6-digit PIN" />
            <Input label="Country" placeholder="India" value="India" />
          </div>
        </div>

        <div className="mt-4">
          <label className="flex items-center space-x-2">
            <input type="checkbox" className="rounded" />
            <span className="text-sm text-gray-700">Same as billing address for shipping</span>
          </label>
        </div>
      </Modal>

      {/* View Customer Modal */}
      <Modal
        isOpen={selectedCustomer !== null}
        onClose={() => setSelectedCustomer(null)}
        title="Customer Details"
        size="lg"
      >
        {selectedCustomer && (
          <div className="space-y-6">
            <div className="grid grid-cols-2 gap-4">
              <div>
                <p className="text-sm text-gray-500">Name</p>
                <p className="font-medium text-gray-900">{selectedCustomer.name}</p>
              </div>
              <div>
                <p className="text-sm text-gray-500">Phone</p>
                <p className="font-medium text-gray-900">{selectedCustomer.phone}</p>
              </div>
              <div>
                <p className="text-sm text-gray-500">Email</p>
                <p className="font-medium text-gray-900">{selectedCustomer.email}</p>
              </div>
              <div>
                <p className="text-sm text-gray-500">City</p>
                <p className="font-medium text-gray-900">{selectedCustomer.city}</p>
              </div>
            </div>

            <div className="grid grid-cols-3 gap-4 pt-4 border-t">
              <div className="text-center">
                <p className="text-2xl font-bold text-blue-600">{selectedCustomer.totalOrders}</p>
                <p className="text-sm text-gray-500">Total Orders</p>
              </div>
              <div className="text-center">
                <p className="text-2xl font-bold text-green-600">₹{selectedCustomer.totalSpent.toLocaleString()}</p>
                <p className="text-sm text-gray-500">Total Spent</p>
              </div>
              <div className="text-center">
                <p className="text-2xl font-bold text-purple-600">{selectedCustomer.lastOrder}</p>
                <p className="text-sm text-gray-500">Last Order</p>
              </div>
            </div>
          </div>
        )}
      </Modal>
    </div>
  );
};

export default Customers;