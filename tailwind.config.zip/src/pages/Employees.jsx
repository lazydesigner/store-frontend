import React, { useState } from 'react';
import { Plus, Edit, Trash2, Shield, Key } from 'lucide-react';
import Card from '../components/common/Card';
import Button from '../components/common/Button';
import Input from '../components/common/Input';
import Select from '../components/common/Select';
import Table from '../components/common/Table';
import Modal from '../components/common/Modal';
import SearchBar from '../components/common/SearchBar';
import Badge from '../components/common/Badge';

const Employees = () => {
  const [searchQuery, setSearchQuery] = useState('');
  const [showAddModal, setShowAddModal] = useState(false);
  const [showRoleModal, setShowRoleModal] = useState(false);
  const [showDiscountModal, setShowDiscountModal] = useState(false);

  const employees = [
    {
      id: 1,
      name: 'Rahul Verma',
      username: 'rahul.v',
      phone: '9876543210',
      role: 'Sales',
      isActive: true,
      joinDate: '2024-01-15'
    },
    {
      id: 2,
      name: 'Sneha Desai',
      username: 'sneha.d',
      phone: '9876543211',
      role: 'Manager',
      isActive: true,
      joinDate: '2023-08-20'
    },
    {
      id: 3,
      name: 'Vikram Singh',
      username: 'vikram.s',
      phone: '9876543212',
      role: 'Delivery',
      isActive: true,
      joinDate: '2024-03-10'
    }
  ];

  const roles = [
    { name: 'Admin', permissions: 45, employees: 2 },
    { name: 'Manager', permissions: 35, employees: 3 },
    { name: 'Sales', permissions: 15, employees: 8 },
    { name: 'Delivery', permissions: 8, employees: 5 },
    { name: 'Finance', permissions: 12, employees: 2 }
  ];

  const columns = [
    {
      key: 'name',
      label: 'Employee Name',
      sortable: true,
      render: (value, row) => (
        <div>
          <p className="font-medium text-gray-900">{value}</p>
          <p className="text-xs text-gray-500">@{row.username}</p>
        </div>
      )
    },
    {
      key: 'phone',
      label: 'Phone',
      render: (value) => <span className="text-sm text-gray-600">{value}</span>
    },
    {
      key: 'role',
      label: 'Role',
      sortable: true,
      render: (value) => {
        const roleColors = {
          Admin: 'danger',
          Manager: 'warning',
          Sales: 'info',
          Delivery: 'success',
          Finance: 'secondary'
        };
        return <Badge variant={roleColors[value]}>{value}</Badge>;
      }
    },
    {
      key: 'joinDate',
      label: 'Join Date',
      sortable: true,
      render: (value) => <span className="text-sm text-gray-500">{value}</span>
    },
    {
      key: 'isActive',
      label: 'Status',
      render: (value) => (
        <Badge variant={value ? 'success' : 'secondary'}>
          {value ? 'Active' : 'Inactive'}
        </Badge>
      )
    },
    {
      key: 'actions',
      label: 'Actions',
      render: (_, row) => (
        <div className="flex items-center space-x-2">
          <button className="p-1 hover:bg-yellow-50 rounded text-yellow-600" title="Edit">
            <Edit className="h-4 w-4" />
          </button>
          <button 
            className="p-1 hover:bg-blue-50 rounded text-blue-600" 
            title="Permissions"
            onClick={() => setShowRoleModal(true)}
          >
            <Shield className="h-4 w-4" />
          </button>
          <button className="p-1 hover:bg-red-50 rounded text-red-600" title="Delete">
            <Trash2 className="h-4 w-4" />
          </button>
        </div>
      )
    }
  ];

  const roleOptions = [
    { value: 'admin', label: 'Admin' },
    { value: 'manager', label: 'Manager' },
    { value: 'sales', label: 'Sales' },
    { value: 'delivery', label: 'Delivery' },
    { value: 'finance', label: 'Finance' }
  ];

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Employees</h1>
          <p className="text-gray-500 mt-1">Manage employees and permissions</p>
        </div>
        <div className="flex items-center space-x-3">
          <Button 
            variant="outline" 
            icon={Shield}
            onClick={() => setShowRoleModal(true)}
          >
            Manage Roles
          </Button>
          <Button 
            variant="outline" 
            icon={Key}
            onClick={() => setShowDiscountModal(true)}
          >
            Discount Limits
          </Button>
          <Button icon={Plus} onClick={() => setShowAddModal(true)}>
            Add Employee
          </Button>
        </div>
      </div>

      {/* Roles Overview */}
      <div className="grid grid-cols-1 md:grid-cols-5 gap-4">
        {roles.map((role, index) => (
          <Card key={index} hover className="text-center">
            <div className="mb-3">
              <Shield className="h-8 w-8 mx-auto text-blue-600" />
            </div>
            <h3 className="font-semibold text-gray-900">{role.name}</h3>
            <p className="text-sm text-gray-500 mt-1">{role.employees} employees</p>
            <p className="text-xs text-gray-400 mt-1">{role.permissions} permissions</p>
          </Card>
        ))}
      </div>

      {/* Search */}
      <Card>
        <SearchBar
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          onClear={() => setSearchQuery('')}
          placeholder="Search by name, username or phone..."
          className="mb-0"
        />
      </Card>

      {/* Table */}
      <Card>
        <Table columns={columns} data={employees} hover={true} />
      </Card>

      {/* Add Employee Modal */}
      <Modal
        isOpen={showAddModal}
        onClose={() => setShowAddModal(false)}
        title="Add New Employee"
        size="md"
        footer={
          <>
            <Button variant="ghost" onClick={() => setShowAddModal(false)}>
              Cancel
            </Button>
            <Button>Create Employee</Button>
          </>
        }
      >
        <div className="space-y-4">
          <Input label="Full Name" placeholder="Enter full name" required />
          <Input label="Username" placeholder="username" required />
          <Input label="Phone Number" placeholder="10-digit mobile" required />
          <Input label="Email" type="email" placeholder="employee@email.com" />
          <Input label="Password" type="password" placeholder="Min 8 characters" required />
          <Select label="Role" options={roleOptions} required />
          
          <div className="pt-4 border-t">
            <label className="flex items-center space-x-2">
              <input type="checkbox" className="rounded" defaultChecked />
              <span className="text-sm text-gray-700">Mark as active</span>
            </label>
          </div>
        </div>
      </Modal>

      {/* Role Management Modal */}
      <Modal
        isOpen={showRoleModal}
        onClose={() => setShowRoleModal(false)}
        title="Manage Role Permissions"
        size="lg"
      >
        <div className="space-y-4">
          <Select 
            label="Select Role" 
            options={roleOptions}
            placeholder="Choose a role to manage"
          />

          <div className="border rounded-lg p-4 space-y-3 max-h-96 overflow-y-auto">
            <h4 className="font-semibold text-gray-900 mb-3">Permissions</h4>
            
            {['Sales', 'Customers', 'Products', 'Inventory', 'Delivery', 'Reports', 'Settings'].map((module) => (
              <div key={module} className="pb-3 border-b border-gray-100 last:border-0">
                <p className="font-medium text-gray-900 mb-2">{module}</p>
                <div className="grid grid-cols-2 gap-2">
                  {['View', 'Create', 'Edit', 'Delete'].map((action) => (
                    <label key={action} className="flex items-center space-x-2">
                      <input type="checkbox" className="rounded" />
                      <span className="text-sm text-gray-700">{action}</span>
                    </label>
                  ))}
                </div>
              </div>
            ))}
          </div>

          <div className="flex justify-end space-x-2 pt-4">
            <Button variant="ghost" onClick={() => setShowRoleModal(false)}>
              Cancel
            </Button>
            <Button>Save Permissions</Button>
          </div>
        </div>
      </Modal>

      {/* Discount Limits Modal */}
      <Modal
        isOpen={showDiscountModal}
        onClose={() => setShowDiscountModal(false)}
        title="Set Discount Limits"
        size="md"
      >
        <div className="space-y-4">
          <Select 
            label="Select Employee/Role" 
            options={[
              { value: 'role_sales', label: 'Role: Sales' },
              { value: 'role_manager', label: 'Role: Manager' },
              { value: 'emp_1', label: 'Rahul Verma' }
            ]}
            placeholder="Choose employee or role"
          />

          <Select 
            label="Product Type (Optional)" 
            options={[
              { value: 'all', label: 'All Products' },
              { value: 'smartphone', label: 'Smartphones' },
              { value: 'laptop', label: 'Laptops' }
            ]}
          />

          <Input 
            label="Maximum Discount (%)" 
            type="number" 
            placeholder="10" 
            helperText="Maximum discount percentage allowed"
          />

          <div className="bg-blue-50 border border-blue-200 rounded p-3 text-sm text-blue-800">
            <strong>Note:</strong> This discount limit will be applied when creating sales invoices.
          </div>

          <div className="flex justify-end space-x-2 pt-4">
            <Button variant="ghost" onClick={() => setShowDiscountModal(false)}>
              Cancel
            </Button>
            <Button>Save Limit</Button>
          </div>
        </div>
      </Modal>
    </div>
  );
};

export default Employees;