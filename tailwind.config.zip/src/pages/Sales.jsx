import React, { useState } from 'react';
import { Plus, FileText, Download, Eye, Trash2, Search, Filter } from 'lucide-react';
import Card from '../components/common/Card';
import Button from '../components/common/Button';
import Input from '../components/common/Input';
import Select from '../components/common/Select';
import Table from '../components/common/Table';
import Modal from '../components/common/Modal';
import Badge from '../components/common/Badge';

const Sales = () => {
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [showInvoiceModal, setShowInvoiceModal] = useState(false);
  const [selectedSale, setSelectedSale] = useState(null);
  const [saleType, setSaleType] = useState('invoice');

  const sales = [
    {
      id: 1,
      invoiceNo: 'INV/2025-26/001',
      type: 'invoice',
      date: '2025-11-01',
      customer: 'Rajesh Kumar',
      amount: 125900,
      paid: 125900,
      status: 'confirmed',
      paymentStatus: 'paid'
    },
    {
      id: 2,
      invoiceNo: 'PI/2025-26/045',
      type: 'proforma',
      date: '2025-11-01',
      customer: 'Priya Sharma',
      amount: 89500,
      paid: 0,
      status: 'confirmed',
      paymentStatus: 'pending'
    },
    {
      id: 3,
      invoiceNo: 'DRAFT-003',
      type: 'draft',
      date: '2025-10-31',
      customer: 'Amit Patel',
      amount: 45200,
      paid: 0,
      status: 'draft',
      paymentStatus: 'pending'
    }
  ];

  const columns = [
    {
      key: 'invoiceNo',
      label: 'Invoice/Draft No',
      sortable: true,
      render: (value, row) => (
        <div>
          <p className="font-medium text-blue-600">{value}</p>
          <Badge variant={row.type === 'invoice' ? 'success' : row.type === 'proforma' ? 'warning' : 'secondary'} size="sm" className="mt-1">
            {row.type}
          </Badge>
        </div>
      )
    },
    {
      key: 'date',
      label: 'Date',
      sortable: true,
      render: (value) => <span className="text-sm text-gray-600">{value}</span>
    },
    {
      key: 'customer',
      label: 'Customer',
      sortable: true,
      render: (value) => <span className="font-medium text-gray-900">{value}</span>
    },
    {
      key: 'amount',
      label: 'Amount',
      sortable: true,
      render: (value) => (
        <span className="font-semibold text-gray-900">₹{value.toLocaleString()}</span>
      )
    },
    {
      key: 'paymentStatus',
      label: 'Payment',
      render: (value, row) => (
        <div>
          <Badge variant={value === 'paid' ? 'success' : value === 'partial' ? 'warning' : 'danger'}>
            {value}
          </Badge>
          {row.paid > 0 && row.paid < row.amount && (
            <p className="text-xs text-gray-500 mt-1">₹{row.paid.toLocaleString()} paid</p>
          )}
        </div>
      )
    },
    {
      key: 'status',
      label: 'Status',
      render: (value) => (
        <Badge variant={value === 'confirmed' ? 'success' : value === 'draft' ? 'warning' : 'danger'}>
          {value}
        </Badge>
      )
    },
    {
      key: 'actions',
      label: 'Actions',
      render: (_, row) => (
        <div className="flex items-center space-x-2">
          <button 
            className="p-1 hover:bg-blue-50 rounded text-blue-600"
            onClick={() => {
              setSelectedSale(row);
              setShowInvoiceModal(true);
            }}
            title="View Invoice"
          >
            <Eye className="h-4 w-4" />
          </button>
          <button className="p-1 hover:bg-green-50 rounded text-green-600" title="Download PDF">
            <Download className="h-4 w-4" />
          </button>
          {row.status === 'draft' && (
            <button className="p-1 hover:bg-red-50 rounded text-red-600" title="Delete">
              <Trash2 className="h-4 w-4" />
            </button>
          )}
        </div>
      )
    }
  ];

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Sales & Invoices</h1>
          <p className="text-gray-500 mt-1">Create and manage sales orders</p>
        </div>
        <Button icon={Plus} onClick={() => setShowCreateModal(true)}>
          Create New Sale
        </Button>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        {[
          { label: 'Today\'s Sales', value: '₹2,45,680', change: '+12%', color: 'green' },
          { label: 'Pending Payments', value: '₹89,500', count: '3 invoices', color: 'yellow' },
          { label: 'Draft Orders', value: '5', count: '₹1,25,000', color: 'blue' },
          { label: 'This Month', value: '₹45,68,900', change: '+24%', color: 'purple' }
        ].map((stat, index) => (
          <Card key={index}>
            <div>
              <p className="text-sm text-gray-500 font-medium">{stat.label}</p>
              <h3 className="text-2xl font-bold text-gray-900 mt-1">{stat.value}</h3>
              <p className="text-sm text-gray-500 mt-1">{stat.change || stat.count}</p>
            </div>
          </Card>
        ))}
      </div>

      {/* Filters */}
      <Card>
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <Input
            placeholder="Search invoice or customer..."
            icon={Search}
            className="mb-0"
          />
          <Select
            placeholder="Filter by Type"
            options={[
              { value: 'all', label: 'All Types' },
              { value: 'invoice', label: 'Invoice' },
              { value: 'proforma', label: 'Proforma' },
              { value: 'draft', label: 'Draft' }
            ]}
            className="mb-0"
          />
          <Select
            placeholder="Payment Status"
            options={[
              { value: 'all', label: 'All Status' },
              { value: 'paid', label: 'Paid' },
              { value: 'partial', label: 'Partial' },
              { value: 'pending', label: 'Pending' }
            ]}
            className="mb-0"
          />
          <Button variant="outline" icon={Filter} fullWidth>
            More Filters
          </Button>
        </div>
      </Card>

      {/* Table */}
      <Card>
        <Table columns={columns} data={sales} hover={true} />
      </Card>

      {/* Create Sale Modal */}
      <Modal
        isOpen={showCreateModal}
        onClose={() => setShowCreateModal(false)}
        title="Create New Sale"
        size="xl"
      >
        <div className="space-y-6">
          {/* Sale Type Selection */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Sale Type
            </label>
            <div className="grid grid-cols-3 gap-4">
              {[
                { value: 'draft', label: 'Draft', desc: 'Save for later' },
                { value: 'proforma', label: 'Proforma Invoice', desc: 'Quotation' },
                { value: 'invoice', label: 'Final Invoice', desc: 'Confirmed sale' }
              ].map((type) => (
                <div
                  key={type.value}
                  onClick={() => setSaleType(type.value)}
                  className={`border-2 rounded-lg p-4 cursor-pointer transition-all ${
                    saleType === type.value
                      ? 'border-blue-600 bg-blue-50'
                      : 'border-gray-200 hover:border-gray-300'
                  }`}
                >
                  <p className="font-medium text-gray-900">{type.label}</p>
                  <p className="text-xs text-gray-500 mt-1">{type.desc}</p>
                </div>
              ))}
            </div>
          </div>

          {/* Customer & Warehouse */}
          <div className="grid grid-cols-2 gap-4">
            <Select
              label="Customer"
              options={[
                { value: '1', label: 'Rajesh Kumar - 9876543210' },
                { value: '2', label: 'Priya Sharma - 9876543211' }
              ]}
              required
              placeholder="Select or search customer"
            />
            <Select
              label="Warehouse"
              options={[
                { value: 'main', label: 'Main Warehouse' },
                { value: 'branch1', label: 'Branch 1' }
              ]}
              required
            />
          </div>

          {/* Items Section */}
          <div>
            <div className="flex items-center justify-between mb-3">
              <h3 className="font-semibold text-gray-900">Order Items</h3>
              <Button size="sm" variant="outline">Add Item</Button>
            </div>

            {/* Sample Item Row */}
            <div className="border rounded-lg p-4 space-y-3 bg-gray-50">
              <div className="grid grid-cols-12 gap-3">
                <div className="col-span-4">
                  <Select
                    label="Product"
                    options={[
                      { value: '1', label: 'iPhone 14 Pro 256GB' }
                    ]}
                    placeholder="Search product"
                    className="mb-0"
                  />
                </div>
                <div className="col-span-2">
                  <Input label="Quantity" type="number" placeholder="1" className="mb-0" />
                </div>
                <div className="col-span-2">
                  <Input label="Price (₹)" type="number" placeholder="125900" className="mb-0" />
                </div>
                <div className="col-span-2">
                  <Input label="Discount (%)" type="number" placeholder="5" className="mb-0" />
                </div>
                <div className="col-span-2 flex items-end">
                  <div className="w-full">
                    <label className="block text-sm font-medium text-gray-700 mb-1">Total</label>
                    <p className="text-lg font-bold text-gray-900">₹119,605</p>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Totals */}
          <div className="border-t pt-4">
            <div className="max-w-sm ml-auto space-y-2">
              <div className="flex justify-between text-sm">
                <span className="text-gray-600">Subtotal:</span>
                <span className="font-medium">₹119,605</span>
              </div>
              <div className="flex justify-between text-sm">
                <span className="text-gray-600">Discount:</span>
                <span className="font-medium text-red-600">-₹6,295</span>
              </div>
              <div className="flex justify-between text-sm">
                <span className="text-gray-600">Tax (18%):</span>
                <span className="font-medium">₹21,529</span>
              </div>
              <div className="flex justify-between text-lg font-bold border-t pt-2">
                <span>Grand Total:</span>
                <span className="text-blue-600">₹1,34,839</span>
              </div>
            </div>
          </div>

          {/* Actions */}
          <div className="flex justify-end space-x-3 pt-4 border-t">
            <Button variant="ghost" onClick={() => setShowCreateModal(false)}>
              Cancel
            </Button>
            {saleType === 'draft' && <Button variant="secondary">Save Draft</Button>}
            {saleType === 'invoice' && <Button>Confirm & Generate Invoice</Button>}
            {saleType === 'proforma' && <Button>Generate Proforma</Button>}
          </div>
        </div>
      </Modal>

      {/* View Invoice Modal */}
      <Modal
        isOpen={showInvoiceModal}
        onClose={() => setShowInvoiceModal(false)}
        title="Invoice Details"
        size="lg"
      >
        {selectedSale && (
          <div className="space-y-4">
            <div className="flex justify-between items-start">
              <div>
                <h2 className="text-2xl font-bold text-gray-900">{selectedSale.invoiceNo}</h2>
                <p className="text-gray-500">Date: {selectedSale.date}</p>
              </div>
              <Badge variant="success" size="lg">PAID</Badge>
            </div>

            <div className="grid grid-cols-2 gap-6 py-4 border-y">
              <div>
                <p className="text-sm text-gray-500 mb-1">Customer</p>
                <p className="font-medium text-gray-900">{selectedSale.customer}</p>
              </div>
              <div>
                <p className="text-sm text-gray-500 mb-1">Amount</p>
                <p className="text-2xl font-bold text-green-600">₹{selectedSale.amount.toLocaleString()}</p>
              </div>
            </div>

            <div className="flex space-x-3">
              <Button icon={Download} fullWidth>Download PDF</Button>
              <Button variant="outline" icon={FileText} fullWidth>Print</Button>
            </div>
          </div>
        )}
      </Modal>
    </div>
  );
};

export default Sales;