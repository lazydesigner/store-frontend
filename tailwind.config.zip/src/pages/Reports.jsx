import React, { useState } from 'react';
import { Download, Calendar, FileText, BarChart3, TrendingUp, DollarSign } from 'lucide-react';
import Card from '../components/common/Card';
import Button from '../components/common/Button';
import Select from '../components/common/Select';
import Input from '../components/common/Input';
import Badge from '../components/common/Badge';

const Reports = () => {
  const [dateRange, setDateRange] = useState('thisMonth');
  const [reportType, setReportType] = useState('sales');

  const reportTypes = [
    { id: 'sales', name: 'Sales Report', icon: BarChart3, color: 'blue' },
    { id: 'stock', name: 'Stock Report', icon: FileText, color: 'green' },
    { id: 'kitty', name: 'Kitty (Commission)', icon: DollarSign, color: 'purple' },
    { id: 'gst', name: 'GST Report', icon: TrendingUp, color: 'orange' }
  ];

  const salesData = [
    { employee: 'Rajesh Kumar', orders: 45, revenue: 1452000, commission: 125000 },
    { employee: 'Priya Sharma', orders: 38, revenue: 1289000, commission: 108000 },
    { employee: 'Amit Patel', orders: 32, revenue: 985000, commission: 82000 }
  ];

  const stockData = [
    { product: 'iPhone 14 Pro', sku: 'IP14P-256', inStock: 45, sold: 78, value: 5805000 },
    { product: 'Samsung S23', sku: 'SGS23-128', inStock: 32, sold: 56, value: 2688000 },
    { product: 'MacBook Air M2', sku: 'MBA-M2', inStock: 8, sold: 23, value: 2760000 }
  ];

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Reports & Analytics</h1>
          <p className="text-gray-500 mt-1">Generate detailed business reports</p>
        </div>
        <Button icon={Download}>
          Export All Reports
        </Button>
      </div>

      {/* Report Type Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        {reportTypes.map((type) => (
          <Card
            key={type.id}
            hover
            className={`cursor-pointer transition-all ${
              reportType === type.id ? 'ring-2 ring-blue-500' : ''
            }`}
            onClick={() => setReportType(type.id)}
          >
            <div className="text-center">
              <div className={`bg-${type.color}-100 rounded-full w-16 h-16 flex items-center justify-center mx-auto mb-3`}>
                <type.icon className={`h-8 w-8 text-${type.color}-600`} />
              </div>
              <h3 className="font-semibold text-gray-900">{type.name}</h3>
            </div>
          </Card>
        ))}
      </div>

      {/* Filters */}
      <Card>
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <Select
            label="Date Range"
            value={dateRange}
            onChange={(e) => setDateRange(e.target.value)}
            options={[
              { value: 'today', label: 'Today' },
              { value: 'yesterday', label: 'Yesterday' },
              { value: 'thisWeek', label: 'This Week' },
              { value: 'thisMonth', label: 'This Month' },
              { value: 'lastMonth', label: 'Last Month' },
              { value: 'custom', label: 'Custom Range' }
            ]}
            className="mb-0"
          />
          <Input
            label="From Date"
            type="date"
            className="mb-0"
          />
          <Input
            label="To Date"
            type="date"
            className="mb-0"
          />
          <div className="flex items-end">
            <Button fullWidth>Generate Report</Button>
          </div>
        </div>
      </Card>

      {/* Sales Report */}
      {reportType === 'sales' && (
        <div className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <Card>
              <div>
                <p className="text-sm text-gray-500 mb-1">Total Revenue</p>
                <h3 className="text-2xl font-bold text-green-600">₹37,26,000</h3>
                <p className="text-sm text-green-600 mt-1">+18% from last month</p>
              </div>
            </Card>
            <Card>
              <div>
                <p className="text-sm text-gray-500 mb-1">Total Orders</p>
                <h3 className="text-2xl font-bold text-blue-600">115</h3>
                <p className="text-sm text-blue-600 mt-1">+12% from last month</p>
              </div>
            </Card>
            <Card>
              <div>
                <p className="text-sm text-gray-500 mb-1">Average Order Value</p>
                <h3 className="text-2xl font-bold text-purple-600">₹32,400</h3>
                <p className="text-sm text-purple-600 mt-1">+5% from last month</p>
              </div>
            </Card>
          </div>

          <Card title="Sales by Employee">
            <div className="overflow-x-auto">
              <table className="min-w-full">
                <thead className="bg-gray-50">
                  <tr>
                    <th className="px-6 py-3 text-left text-xs font-semibold text-gray-600 uppercase">Employee</th>
                    <th className="px-6 py-3 text-left text-xs font-semibold text-gray-600 uppercase">Orders</th>
                    <th className="px-6 py-3 text-left text-xs font-semibold text-gray-600 uppercase">Revenue</th>
                    <th className="px-6 py-3 text-left text-xs font-semibold text-gray-600 uppercase">Commission</th>
                    <th className="px-6 py-3 text-left text-xs font-semibold text-gray-600 uppercase">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-200">
                  {salesData.map((row, index) => (
                    <tr key={index} className="hover:bg-gray-50">
                      <td className="px-6 py-4 text-sm font-medium text-gray-900">{row.employee}</td>
                      <td className="px-6 py-4 text-sm text-gray-600">{row.orders}</td>
                      <td className="px-6 py-4 text-sm font-semibold text-green-600">₹{row.revenue.toLocaleString()}</td>
                      <td className="px-6 py-4 text-sm font-semibold text-purple-600">₹{row.commission.toLocaleString()}</td>
                      <td className="px-6 py-4 text-sm">
                        <Button size="sm" variant="outline">View Details</Button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </Card>
        </div>
      )}

      {/* Stock Report */}
      {reportType === 'stock' && (
        <Card title="Inventory Summary">
          <div className="overflow-x-auto">
            <table className="min-w-full">
              <thead className="bg-gray-50">
                <tr>
                  <th className="px-6 py-3 text-left text-xs font-semibold text-gray-600 uppercase">Product</th>
                  <th className="px-6 py-3 text-left text-xs font-semibold text-gray-600 uppercase">SKU</th>
                  <th className="px-6 py-3 text-left text-xs font-semibold text-gray-600 uppercase">In Stock</th>
                  <th className="px-6 py-3 text-left text-xs font-semibold text-gray-600 uppercase">Sold</th>
                  <th className="px-6 py-3 text-left text-xs font-semibold text-gray-600 uppercase">Stock Value</th>
                  <th className="px-6 py-3 text-left text-xs font-semibold text-gray-600 uppercase">Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-200">
                {stockData.map((row, index) => (
                  <tr key={index} className="hover:bg-gray-50">
                    <td className="px-6 py-4 text-sm font-medium text-gray-900">{row.product}</td>
                    <td className="px-6 py-4 text-sm text-gray-600 font-mono">{row.sku}</td>
                    <td className="px-6 py-4 text-sm text-gray-900">{row.inStock} units</td>
                    <td className="px-6 py-4 text-sm text-gray-600">{row.sold} units</td>
                    <td className="px-6 py-4 text-sm font-semibold text-green-600">₹{row.value.toLocaleString()}</td>
                    <td className="px-6 py-4 text-sm">
                      <Badge variant={row.inStock < 10 ? 'danger' : row.inStock < 20 ? 'warning' : 'success'}>
                        {row.inStock < 10 ? 'Low Stock' : 'In Stock'}
                      </Badge>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </Card>
      )}

      {/* Kitty Report */}
      {reportType === 'kitty' && (
        <div className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <Card>
              <div>
                <p className="text-sm text-gray-500 mb-1">Total Commission</p>
                <h3 className="text-2xl font-bold text-purple-600">₹3,15,000</h3>
                <p className="text-sm text-gray-500 mt-1">This month</p>
              </div>
            </Card>
            <Card>
              <div>
                <p className="text-sm text-gray-500 mb-1">Paid Out</p>
                <h3 className="text-2xl font-bold text-green-600">₹2,80,000</h3>
                <p className="text-sm text-gray-500 mt-1">This month</p>
              </div>
            </Card>
            <Card>
              <div>
                <p className="text-sm text-gray-500 mb-1">Pending</p>
                <h3 className="text-2xl font-bold text-orange-600">₹35,000</h3>
                <p className="text-sm text-gray-500 mt-1">To be paid</p>
              </div>
            </Card>
          </div>

          <Card title="Employee Commission Details">
            <div className="space-y-4">
              {salesData.map((emp, index) => (
                <div key={index} className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                  <div className="flex items-center space-x-4">
                    <div className="bg-purple-100 rounded-full w-12 h-12 flex items-center justify-center">
                      <span className="font-bold text-purple-600">#{index + 1}</span>
                    </div>
                    <div>
                      <p className="font-semibold text-gray-900">{emp.employee}</p>
                      <p className="text-sm text-gray-500">{emp.orders} orders • ₹{emp.revenue.toLocaleString()} revenue</p>
                    </div>
                  </div>
                  <div className="text-right">
                    <p className="text-2xl font-bold text-purple-600">₹{emp.commission.toLocaleString()}</p>
                    <Button size="sm" variant="outline" className="mt-2">Process Payment</Button>
                  </div>
                </div>
              ))}
            </div>
          </Card>
        </div>
      )}

      {/* GST Report */}
      {reportType === 'gst' && (
        <Card title="GST Summary">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
            <div className="bg-blue-50 rounded-lg p-6">
              <p className="text-sm text-gray-600 mb-2">Total Taxable Value</p>
              <h3 className="text-3xl font-bold text-blue-600">₹31,55,932</h3>
            </div>
            <div className="bg-green-50 rounded-lg p-6">
              <p className="text-sm text-gray-600 mb-2">Total GST Collected</p>
              <h3 className="text-3xl font-bold text-green-600">₹5,68,068</h3>
            </div>
          </div>

          <div className="overflow-x-auto">
            <table className="min-w-full">
              <thead className="bg-gray-50">
                <tr>
                  <th className="px-6 py-3 text-left text-xs font-semibold text-gray-600 uppercase">GST Rate</th>
                  <th className="px-6 py-3 text-left text-xs font-semibold text-gray-600 uppercase">Taxable Amount</th>
                  <th className="px-6 py-3 text-left text-xs font-semibold text-gray-600 uppercase">CGST</th>
                  <th className="px-6 py-3 text-left text-xs font-semibold text-gray-600 uppercase">SGST</th>
                  <th className="px-6 py-3 text-left text-xs font-semibold text-gray-600 uppercase">Total GST</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-200">
                {[
                  { rate: '5%', taxable: 850000, cgst: 21250, sgst: 21250 },
                  { rate: '12%', taxable: 1200000, cgst: 72000, sgst: 72000 },
                  { rate: '18%', taxable: 2855932, cgst: 257034, sgst: 257034 }
                ].map((row, index) => (
                  <tr key={index} className="hover:bg-gray-50">
                    <td className="px-6 py-4 text-sm font-medium text-gray-900">{row.rate}</td>
                    <td className="px-6 py-4 text-sm text-gray-900">₹{row.taxable.toLocaleString()}</td>
                    <td className="px-6 py-4 text-sm text-gray-600">₹{row.cgst.toLocaleString()}</td>
                    <td className="px-6 py-4 text-sm text-gray-600">₹{row.sgst.toLocaleString()}</td>
                    <td className="px-6 py-4 text-sm font-semibold text-green-600">
                      ₹{(row.cgst + row.sgst).toLocaleString()}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          <div className="mt-6 flex justify-end space-x-3">
            <Button variant="outline" icon={Download}>Download GSTR-1</Button>
            <Button variant="outline" icon={Download}>Download GSTR-3B</Button>
          </div>
        </Card>
      )}
    </div>
  );
};

export default Reports;