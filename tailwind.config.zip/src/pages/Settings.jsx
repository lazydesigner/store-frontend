import React, { useState } from 'react';
import { Save, Building, FileText, Bell, Shield, Database } from 'lucide-react';
import Card from '../components/common/Card';
import Button from '../components/common/Button';
import Input from '../components/common/Input';
import Select from '../components/common/Select';

const Settings = () => {
  const [activeTab, setActiveTab] = useState('company');

  const tabs = [
    { id: 'company', name: 'Company Info', icon: Building },
    { id: 'invoice', name: 'Invoice Settings', icon: FileText },
    { id: 'notifications', name: 'Notifications', icon: Bell },
    { id: 'security', name: 'Security', icon: Shield },
    { id: 'backup', name: 'Backup & Data', icon: Database }
  ];

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h1 className="text-3xl font-bold text-gray-900">Settings</h1>
        <p className="text-gray-500 mt-1">Manage your store configuration</p>
      </div>

      {/* Tabs */}
      <div className="border-b border-gray-200">
        <div className="flex space-x-8 overflow-x-auto">
          {tabs.map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`flex items-center space-x-2 py-4 px-1 border-b-2 font-medium text-sm whitespace-nowrap ${
                activeTab === tab.id
                  ? 'border-blue-600 text-blue-600'
                  : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
              }`}
            >
              <tab.icon className="h-5 w-5" />
              <span>{tab.name}</span>
            </button>
          ))}
        </div>
      </div>

      {/* Company Info Tab */}
      {activeTab === 'company' && (
        <Card title="Company Information">
          <div className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <Input label="Company Name" placeholder="Electronics Store Pvt Ltd" defaultValue="Electronics Store" />
              <Input label="GSTIN" placeholder="22AAAAA0000A1Z5" />
              <Input label="PAN Number" placeholder="AAAAA0000A" />
              <Input label="CIN" placeholder="U12345XX2020PTC123456" />
            </div>

            <div className="grid grid-cols-1 gap-4">
              <Input label="Address Line 1" placeholder="Building, Street" />
              <Input label="Address Line 2" placeholder="Area, Landmark" />
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <Input label="City" placeholder="Mumbai" />
              <Input label="State" placeholder="Maharashtra" />
              <Input label="PIN Code" placeholder="400001" />
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <Input label="Phone" placeholder="+91 9876543210" />
              <Input label="Email" placeholder="info@store.com" type="email" />
            </div>

            <div className="flex justify-end pt-4">
              <Button icon={Save}>Save Company Info</Button>
            </div>
          </div>
        </Card>
      )}

      {/* Invoice Settings Tab */}
      {activeTab === 'invoice' && (
        <div className="space-y-6">
          <Card title="Invoice Configuration">
            <div className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <Input label="Invoice Prefix" placeholder="INV" defaultValue="INV" />
                <Input label="Proforma Prefix" placeholder="PI" defaultValue="PI" />
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <Input label="Starting Number" type="number" placeholder="1" defaultValue="1" />
                <Select
                  label="Financial Year Format"
                  options={[
                    { value: 'yyyy-yy', label: '2025-26' },
                    { value: 'yyyy', label: '2025' }
                  ]}
                  defaultValue="yyyy-yy"
                />
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <Input label="Default Tax Rate (%)" type="number" placeholder="18" defaultValue="18" />
                <Select
                  label="Tax Type"
                  options={[
                    { value: 'gst', label: 'GST (CGST + SGST)' },
                    { value: 'igst', label: 'IGST' }
                  ]}
                  defaultValue="gst"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Invoice Footer Note
                </label>
                <textarea
                  rows={3}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                  placeholder="Thank you for your business..."
                  defaultValue="Thank you for your business. Please make payment within 30 days."
                />
              </div>

              <div className="space-y-2">
                <label className="flex items-center space-x-2">
                  <input type="checkbox" className="rounded" defaultChecked />
                  <span className="text-sm text-gray-700">Show company logo on invoice</span>
                </label>
                <label className="flex items-center space-x-2">
                  <input type="checkbox" className="rounded" defaultChecked />
                  <span className="text-sm text-gray-700">Show payment QR code</span>
                </label>
                <label className="flex items-center space-x-2">
                  <input type="checkbox" className="rounded" defaultChecked />
                  <span className="text-sm text-gray-700">Show terms & conditions</span>
                </label>
              </div>

              <div className="flex justify-end pt-4">
                <Button icon={Save}>Save Invoice Settings</Button>
              </div>
            </div>
          </Card>
        </div>
      )}

      {/* Notifications Tab */}
      {activeTab === 'notifications' && (
        <div className="space-y-6">
          <Card title="SMS Notifications">
            <div className="space-y-4">
              <Input label="SMS Provider API Key" type="password" placeholder="Enter API key" />
              <Input label="Sender ID" placeholder="STORE" />

              <div className="space-y-2">
                <p className="text-sm font-medium text-gray-700">Send SMS for:</p>
                <label className="flex items-center space-x-2">
                  <input type="checkbox" className="rounded" defaultChecked />
                  <span className="text-sm text-gray-700">Order confirmation</span>
                </label>
                <label className="flex items-center space-x-2">
                  <input type="checkbox" className="rounded" defaultChecked />
                  <span className="text-sm text-gray-700">Out for delivery (with OTP)</span>
                </label>
                <label className="flex items-center space-x-2">
                  <input type="checkbox" className="rounded" defaultChecked />
                  <span className="text-sm text-gray-700">Order delivered</span>
                </label>
                <label className="flex items-center space-x-2">
                  <input type="checkbox" className="rounded" />
                  <span className="text-sm text-gray-700">Payment received</span>
                </label>
              </div>

              <div className="flex justify-end pt-4">
                <Button icon={Save}>Save SMS Settings</Button>
              </div>
            </div>
          </Card>

          <Card title="Email Notifications">
            <div className="space-y-4">
              <Input label="SMTP Host" placeholder="smtp.gmail.com" />
              <Input label="SMTP Port" type="number" placeholder="587" />
              <Input label="SMTP Username" placeholder="email@gmail.com" />
              <Input label="SMTP Password" type="password" placeholder="App password" />

              <div className="space-y-2">
                <p className="text-sm font-medium text-gray-700">Send email for:</p>
                <label className="flex items-center space-x-2">
                  <input type="checkbox" className="rounded" defaultChecked />
                  <span className="text-sm text-gray-700">Invoice generation</span>
                </label>
                <label className="flex items-center space-x-2">
                  <input type="checkbox" className="rounded" defaultChecked />
                  <span className="text-sm text-gray-700">Payment reminders</span>
                </label>
                <label className="flex items-center space-x-2">
                  <input type="checkbox" className="rounded" />
                  <span className="text-sm text-gray-700">Low stock alerts</span>
                </label>
              </div>

              <div className="flex justify-end pt-4">
                <Button icon={Save}>Save Email Settings</Button>
              </div>
            </div>
          </Card>
        </div>
      )}

      {/* Security Tab */}
      {activeTab === 'security' && (
        <div className="space-y-6">
          <Card title="Password Policy">
            <div className="space-y-4">
              <Input label="Minimum Password Length" type="number" defaultValue="8" />
              <Input label="Password Expiry (Days)" type="number" defaultValue="90" />

              <div className="space-y-2">
                <p className="text-sm font-medium text-gray-700">Password Requirements:</p>
                <label className="flex items-center space-x-2">
                  <input type="checkbox" className="rounded" defaultChecked />
                  <span className="text-sm text-gray-700">Require uppercase letter</span>
                </label>
                <label className="flex items-center space-x-2">
                  <input type="checkbox" className="rounded" defaultChecked />
                  <span className="text-sm text-gray-700">Require lowercase letter</span>
                </label>
                <label className="flex items-center space-x-2">
                  <input type="checkbox" className="rounded" defaultChecked />
                  <span className="text-sm text-gray-700">Require number</span>
                </label>
                <label className="flex items-center space-x-2">
                  <input type="checkbox" className="rounded" />
                  <span className="text-sm text-gray-700">Require special character</span>
                </label>
              </div>

              <div className="flex justify-end pt-4">
                <Button icon={Save}>Save Security Settings</Button>
              </div>
            </div>
          </Card>

          <Card title="Two-Factor Authentication">
            <div className="space-y-4">
              <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
                <p className="text-sm text-blue-800">
                  Enable 2FA for enhanced security. Users will need to enter a code from their authenticator app.
                </p>
              </div>

              <label className="flex items-center space-x-2">
                <input type="checkbox" className="rounded" />
                <span className="text-sm text-gray-700">Enable 2FA for all users</span>
              </label>

              <div className="flex justify-end pt-4">
                <Button icon={Save}>Save 2FA Settings</Button>
              </div>
            </div>
          </Card>
        </div>
      )}

      {/* Backup Tab */}
      {activeTab === 'backup' && (
        <div className="space-y-6">
          <Card title="Database Backup">
            <div className="space-y-4">
              <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-4">
                <p className="text-sm text-yellow-800">
                  <strong>Last backup:</strong> November 01, 2025 at 02:00 AM
                </p>
              </div>

              <Select
                label="Automatic Backup Frequency"
                options={[
                  { value: 'daily', label: 'Daily' },
                  { value: 'weekly', label: 'Weekly' },
                  { value: 'monthly', label: 'Monthly' }
                ]}
                defaultValue="daily"
              />

              <Input label="Backup Retention (Days)" type="number" defaultValue="30" />

              <div className="flex space-x-3 pt-4">
                <Button variant="outline">Download Latest Backup</Button>
                <Button>Create Backup Now</Button>
              </div>
            </div>
          </Card>

          <Card title="Data Export">
            <div className="space-y-4">
              <p className="text-sm text-gray-600">
                Export all your data for compliance or migration purposes.
              </p>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                <Button variant="outline" fullWidth>Export All Products</Button>
                <Button variant="outline" fullWidth>Export All Customers</Button>
                <Button variant="outline" fullWidth>Export All Sales</Button>
                <Button variant="outline" fullWidth>Export All Employees</Button>
              </div>
            </div>
          </Card>
        </div>
      )}
    </div>
  );
};

export default Settings;