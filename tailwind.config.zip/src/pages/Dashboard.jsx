import React from 'react';
import { TrendingUp, ShoppingCart, Users, Package, DollarSign, AlertCircle } from 'lucide-react';
import Card from '../components/common/Card';
import Badge from '../components/common/Badge';

const Dashboard = () => {
  const stats = [
    {
      title: 'Total Sales',
      value: '₹2,45,680',
      change: '+12.5%',
      changeType: 'increase',
      icon: DollarSign,
      color: 'bg-green-500'
    },
    {
      title: 'Orders',
      value: '156',
      change: '+8.2%',
      changeType: 'increase',
      icon: ShoppingCart,
      color: 'bg-blue-500'
    },
    {
      title: 'Customers',
      value: '1,245',
      change: '+3.1%',
      changeType: 'increase',
      icon: Users,
      color: 'bg-purple-500'
    },
    {
      title: 'Products',
      value: '456',
      change: '-2.4%',
      changeType: 'decrease',
      icon: Package,
      color: 'bg-orange-500'
    }
  ];

  const recentOrders = [
    { id: 'INV-001', customer: 'John Doe', amount: '₹15,450', status: 'confirmed', date: '01/11/2025' },
    { id: 'INV-002', customer: 'Jane Smith', amount: '₹28,900', status: 'confirmed', date: '01/11/2025' },
    { id: 'INV-003', customer: 'Bob Johnson', amount: '₹9,500', status: 'draft', date: '31/10/2025' },
    { id: 'INV-004', customer: 'Alice Brown', amount: '₹42,300', status: 'confirmed', date: '31/10/2025' }
  ];

  const lowStockItems = [
    { name: 'iPhone 14 Pro', sku: 'IP14P-128', stock: 3, minStock: 10 },
    { name: 'Samsung Galaxy S23', sku: 'SGS23-256', stock: 5, minStock: 15 },
    { name: 'MacBook Air M2', sku: 'MBA-M2-512', stock: 2, minStock: 8 }
  ];

  const topSellers = [
    { name: 'Rajesh Kumar', sales: '₹1,45,200', orders: 45, commission: '₹12,500' },
    { name: 'Priya Sharma', sales: '₹1,28,900', orders: 38, commission: '₹10,800' },
    { name: 'Amit Patel', sales: '₹98,500', orders: 32, commission: '₹8,200' }
  ];

  const getStatusBadge = (status) => {
    const variants = {
      confirmed: 'success',
      draft: 'warning',
      cancelled: 'danger'
    };
    return <Badge variant={variants[status]}>{status.charAt(0).toUpperCase() + status.slice(1)}</Badge>;
  };

  return (
    <div className="space-y-6">
      {/* Page Header */}
      <div>
        <h1 className="text-3xl font-bold text-gray-900">Dashboard</h1>
        <p className="text-gray-500 mt-1">Welcome back! Here's what's happening today.</p>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {stats.map((stat, index) => (
          <Card key={index} className="relative overflow-hidden">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-500 font-medium">{stat.title}</p>
                <h3 className="text-2xl font-bold text-gray-900 mt-1">{stat.value}</h3>
                <div className="flex items-center mt-2">
                  <TrendingUp className={`h-4 w-4 ${stat.changeType === 'increase' ? 'text-green-500' : 'text-red-500'}`} />
                  <span className={`text-sm ml-1 ${stat.changeType === 'increase' ? 'text-green-600' : 'text-red-600'}`}>
                    {stat.change}
                  </span>
                  <span className="text-sm text-gray-500 ml-1">vs last month</span>
                </div>
              </div>
              <div className={`${stat.color} p-3 rounded-lg`}>
                <stat.icon className="h-6 w-6 text-white" />
              </div>
            </div>
          </Card>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Recent Orders */}
        <Card title="Recent Orders" className="lg:col-span-2">
          <div className="overflow-x-auto">
            <table className="min-w-full">
              <thead>
                <tr className="border-b border-gray-200">
                  <th className="text-left py-3 px-2 text-sm font-semibold text-gray-600">Invoice</th>
                  <th className="text-left py-3 px-2 text-sm font-semibold text-gray-600">Customer</th>
                  <th className="text-left py-3 px-2 text-sm font-semibold text-gray-600">Amount</th>
                  <th className="text-left py-3 px-2 text-sm font-semibold text-gray-600">Status</th>
                  <th className="text-left py-3 px-2 text-sm font-semibold text-gray-600">Date</th>
                </tr>
              </thead>
              <tbody>
                {recentOrders.map((order) => (
                  <tr key={order.id} className="border-b border-gray-100 hover:bg-gray-50">
                    <td className="py-3 px-2 text-sm font-medium text-blue-600">{order.id}</td>
                    <td className="py-3 px-2 text-sm text-gray-900">{order.customer}</td>
                    <td className="py-3 px-2 text-sm font-semibold text-gray-900">{order.amount}</td>
                    <td className="py-3 px-2 text-sm">{getStatusBadge(order.status)}</td>
                    <td className="py-3 px-2 text-sm text-gray-500">{order.date}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </Card>

        {/* Low Stock Alert */}
        <Card 
          title="Low Stock Alert" 
          headerActions={
            <Badge variant="danger">
              <AlertCircle className="h-3 w-3 mr-1" />
              {lowStockItems.length}
            </Badge>
          }
        >
          <div className="space-y-4">
            {lowStockItems.map((item, index) => (
              <div key={index} className="flex items-start justify-between pb-4 border-b border-gray-100 last:border-0 last:pb-0">
                <div className="flex-1">
                  <p className="text-sm font-medium text-gray-900">{item.name}</p>
                  <p className="text-xs text-gray-500 mt-0.5">{item.sku}</p>
                  <div className="flex items-center mt-2">
                    <div className="flex-1 bg-gray-200 rounded-full h-2">
                      <div 
                        className="bg-red-500 h-2 rounded-full" 
                        style={{ width: `${(item.stock / item.minStock) * 100}%` }}
                      ></div>
                    </div>
                    <span className="text-xs text-gray-500 ml-2">{item.stock}/{item.minStock}</span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </Card>
      </div>

      {/* Top Sellers */}
      <Card title="Top Sellers (Kitty Leaderboard)" subtitle="Based on this month's performance">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {topSellers.map((seller, index) => (
            <div key={index} className="bg-gradient-to-br from-blue-50 to-blue-100 rounded-lg p-6 relative">
              <div className="absolute top-3 right-3">
                <span className="inline-flex items-center justify-center w-8 h-8 bg-blue-600 text-white rounded-full text-sm font-bold">
                  #{index + 1}
                </span>
              </div>
              <h4 className="font-semibold text-gray-900 text-lg">{seller.name}</h4>
              <div className="mt-4 space-y-2">
                <div className="flex justify-between items-center">
                  <span className="text-sm text-gray-600">Total Sales</span>
                  <span className="font-semibold text-gray-900">{seller.sales}</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-sm text-gray-600">Orders</span>
                  <span className="font-semibold text-gray-900">{seller.orders}</span>
                </div>
                <div className="flex justify-between items-center pt-2 border-t border-blue-200">
                  <span className="text-sm text-gray-600">Commission</span>
                  <span className="font-bold text-green-600">{seller.commission}</span>
                </div>
              </div>
            </div>
          ))}
        </div>
      </Card>
    </div>
  );
};

export default Dashboard;