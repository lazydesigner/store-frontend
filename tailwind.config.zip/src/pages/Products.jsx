import React, { useState } from 'react';
import { Plus, Upload, Download, Search, Filter, Edit, Trash2, Eye, Warehouse } from 'lucide-react';
import Card from '../components/common/Card';
import Button from '../components/common/Button';
import Input from '../components/common/Input';
import Select from '../components/common/Select';
import Table from '../components/common/Table';
import Badge from '../components/common/Badge';
import Modal from '../components/common/Modal';

const Products = () => {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedType, setSelectedType] = useState('');
  const [selectedCompany, setSelectedCompany] = useState('');
  const [showAddModal, setShowAddModal] = useState(false);
  const [showImportModal, setShowImportModal] = useState(false);

  const products = [
    {
      id: 1,
      sku: 'IP14P-256-BL',
      name: 'iPhone 14 Pro 256GB',
      type: 'Smartphone',
      company: 'Apple',
      minPrice: 115000,
      maxPrice: 129900,
      Warehouse: 'Main Warehouse',
      stock: 45,
      isActive: true
    },
    {
      id: 2,
      sku: 'SGS23-128-BK',
      name: 'Samsung Galaxy S23 128GB',
      type: 'Smartphone',
      company: 'Samsung',
      minPrice: 74999,
      maxPrice: 84999,
      Warehouse: 'Main Warehouse',
      stock: 32,
      isActive: true
    },
    {
      id: 3,
      sku: 'MBA-M2-512',
      name: 'MacBook Air M2 512GB',
      type: 'Laptop',
      company: 'Apple',
      minPrice: 120000,
      maxPrice: 134900,
      Warehouse: 'Branck 1',
      stock: 8,
      isActive: true
    },
    {
      id: 4,
      sku: 'LGTV-55-OLED',
      name: 'LG 55" OLED TV',
      type: 'Television',
      company: 'LG',
      minPrice: 89999,
      maxPrice: 105000,
      Warehouse: 'Main Warehouse',
      stock: 15,
      isActive: true
    }
  ];

  const columns = [
    {
      key: 'sku',
      label: 'SKU',
      sortable: true,
      render: (value) => <span className="font-mono text-sm text-gray-600">{value}</span>
    },
    {
      key: 'name',
      label: 'Product Name',
      sortable: true,
      render: (value) => <span className="font-medium text-gray-900">{value}</span>
    },
    {
      key: 'type',
      label: 'Type',
      sortable: true
    },
    {
      key: 'company',
      label: 'Company',
      sortable: true
    },
    {
      key: 'priceRange',
      label: 'Price Range',
      render: (_, row) => (
        <span className="text-sm text-gray-900">
          ₹{row.minPrice.toLocaleString()} - ₹{row.maxPrice.toLocaleString()}
        </span>
      )
    },
    {
      key: 'stock',
      label: 'Stock',
      render: (value) => (
        <Badge variant={value < 10 ? 'danger' : value < 20 ? 'warning' : 'success'}>
          {value} units
        </Badge>
      )
    },
    {
      key: 'Warehouse',
      label: 'Warehouse',
      render: (value) => <span className="font-mono text-sm text-gray-600">{value}</span>
    },
    {
      key: 'isActive',
      label: 'Status',
      render: (value) => (
        <Badge variant={value ? 'success' : 'secondary'}>
          {value ? 'Active' : 'Inactive'}
        </Badge>
      )
    },
    {
      key: 'actions',
      label: 'Actions',
      render: (_, row) => (
        <div className="flex items-center space-x-2">
          <button className="p-1 hover:bg-blue-50 rounded text-blue-600" title="View">
            <Eye className="h-4 w-4" />
          </button>
          <button className="p-1 hover:bg-yellow-50 rounded text-yellow-600" title="Edit">
            <Edit className="h-4 w-4" />
          </button>
          <button className="p-1 hover:bg-red-50 rounded text-red-600" title="Delete">
            <Trash2 className="h-4 w-4" />
          </button>
        </div>
      )
    }
  ];

  const typeOptions = [
    { value: 'smartphone', label: 'Smartphone' },
    { value: 'laptop', label: 'Laptop' },
    { value: 'television', label: 'Television' },
    { value: 'accessories', label: 'Accessories' }
  ];

  const companyOptions = [
    { value: 'apple', label: 'Apple' },
    { value: 'samsung', label: 'Samsung' },
    { value: 'lg', label: 'LG' },
    { value: 'sony', label: 'Sony' }
  ];

  return (
    <div className="space-y-6">
      {/* Page Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Products</h1>
          <p className="text-gray-500 mt-1">Manage your product inventory</p>
        </div>
        <div className="flex items-center space-x-3">
          <Button variant="outline" icon={Upload} onClick={() => setShowImportModal(true)}>
            Import
          </Button>
          <Button variant="outline" icon={Download}>
            Export
          </Button>
          <Button icon={Plus} onClick={() => setShowAddModal(true)}>
            Add Product
          </Button>
        </div>
      </div>

      {/* Filters */}
      <Card>
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <Input
            placeholder="Search by name or SKU..."
            icon={Search}
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="mb-0"
          />
          <Select
            placeholder="Filter by Type"
            options={typeOptions}
            value={selectedType}
            onChange={(e) => setSelectedType(e.target.value)}
            className="mb-0"
          />
          <Select
            placeholder="Filter by Company"
            options={companyOptions}
            value={selectedCompany}
            onChange={(e) => setSelectedCompany(e.target.value)}
            className="mb-0"
          />
          <Button variant="outline" icon={Filter} fullWidth>
            Advanced Filters
          </Button>
        </div>
      </Card>

      {/* Products Table */}
      <Card>
        <Table
          columns={columns}
          data={products}
          hover={true}
        />
      </Card>

      {/* Add Product Modal */}
      <Modal
        isOpen={showAddModal}
        onClose={() => setShowAddModal(false)}
        title="Add New Product"
        size="lg"
        footer={
          <>
            <Button variant="ghost" onClick={() => setShowAddModal(false)}>
              Cancel
            </Button>
            <Button>Save Product</Button>
          </>
        }
      >
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <Input label="Product Name" placeholder="Enter product name" required />
          <Input label="SKU" placeholder="Enter SKU" required />
          <Select label="Product Type" options={typeOptions} required />
          <Select label="Company" options={companyOptions} required />
          <Input label="HSN Code" placeholder="Enter HSN code" />
          <Input label="Tax Rate (%)" type="number" placeholder="18" />
          <Input label="Minimum Price (₹)" type="number" placeholder="10000" required />
          <Input label="Maximum Price (₹)" type="number" placeholder="15000" required />
          <Input label="Initial Stock" type="number" placeholder="50" />
          <Select
            label="Warehouse"
            options={[
              { value: 'main', label: 'Main Warehouse' },
              { value: 'branch1', label: 'Branch 1' }
            ]}
            required
          />
        </div>
        <div className="mt-4">
          <label className="flex items-center space-x-2">
            <input type="checkbox" className="rounded" defaultChecked />
            <span className="text-sm text-gray-700">Mark as active</span>
          </label>
        </div>
      </Modal>

      {/* Import Modal */}
      <Modal
        isOpen={showImportModal}
        onClose={() => setShowImportModal(false)}
        title="Import Products"
        size="md"
        footer={
          <>
            <Button variant="ghost" onClick={() => setShowImportModal(false)}>
              Cancel
            </Button>
            <Button>Upload & Import</Button>
          </>
        }
      >
        <div className="space-y-4">
          <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
            <h4 className="font-medium text-blue-900 mb-2">Import Instructions</h4>
            <ul className="text-sm text-blue-800 space-y-1 list-disc list-inside">
              <li>Download the template file first</li>
              <li>Fill in all required fields</li>
              <li>Upload the completed Excel file</li>
              <li>Review and confirm before importing</li>
            </ul>
          </div>

          <Button variant="outline" fullWidth icon={Download}>
            Download Template (Excel)
          </Button>

          <div className="border-2 border-dashed border-gray-300 rounded-lg p-8 text-center hover:border-blue-400 transition-colors cursor-pointer">
            <Upload className="h-12 w-12 text-gray-400 mx-auto mb-3" />
            <p className="text-sm text-gray-600">
              Click to upload or drag and drop
            </p>
            <p className="text-xs text-gray-500 mt-1">
              Excel files only (Max 5MB)
            </p>
          </div>
        </div>
      </Modal>
    </div>
  );
};

export default Products;