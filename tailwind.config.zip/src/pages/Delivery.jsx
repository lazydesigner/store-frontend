import React, { useState } from 'react';
import { Package, Truck, MapPin, Clock, CheckCircle, XCircle, User } from 'lucide-react';
import Card from '../components/common/Card';
import Button from '../components/common/Button';
import Input from '../components/common/Input';
import Select from '../components/common/Select';
import Badge from '../components/common/Badge';
import Modal from '../components/common/Modal';

const Delivery = () => {
  const [showAssignModal, setShowAssignModal] = useState(false);
  const [showOtpModal, setShowOtpModal] = useState(false);
  const [showTimelineModal, setShowTimelineModal] = useState(false);
  const [selectedDelivery, setSelectedDelivery] = useState(null);

  const deliveries = [
    {
      id: 1,
      orderNo: 'INV/2025-26/001',
      customer: 'Rajesh Kumar',
      phone: '9876543210',
      address: 'Andheri West, Mumbai',
      assignedTo: 'Vikram Singh',
      status: 'out_for_delivery',
      date: '2025-11-01'
    },
    {
      id: 2,
      orderNo: 'INV/2025-26/002',
      customer: 'Priya Sharma',
      phone: '9876543211',
      address: 'Connaught Place, Delhi',
      assignedTo: null,
      status: 'ready_to_ship',
      date: '2025-11-01'
    },
    {
      id: 3,
      orderNo: 'INV/2025-26/003',
      customer: 'Amit Patel',
      phone: '9876543212',
      address: 'Satellite, Ahmedabad',
      assignedTo: 'Rahul Verma',
      status: 'delivered',
      date: '2025-10-31'
    }
  ];

  const getStatusColor = (status) => {
    const colors = {
      new: 'secondary',
      processing: 'warning',
      ready_to_ship: 'info',
      out_for_delivery: 'warning',
      delivered: 'success',
      cancelled: 'danger',
      failed: 'danger'
    };
    return colors[status] || 'secondary';
  };

  const getStatusLabel = (status) => {
    const labels = {
      new: 'New',
      processing: 'Processing',
      ready_to_ship: 'Ready to Ship',
      out_for_delivery: 'Out for Delivery',
      delivered: 'Delivered',
      cancelled: 'Cancelled',
      failed: 'Failed'
    };
    return labels[status] || status;
  };

  const statusCounts = {
    new: 5,
    ready_to_ship: 8,
    out_for_delivery: 12,
    delivered: 145
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Delivery Management</h1>
          <p className="text-gray-500 mt-1">Track and manage deliveries</p>
        </div>
      </div>

      {/* Status Overview */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        {[
          { icon: Package, label: 'New Orders', count: statusCounts.new, color: 'blue' },
          { icon: Clock, label: 'Ready to Ship', count: statusCounts.ready_to_ship, color: 'yellow' },
          { icon: Truck, label: 'Out for Delivery', count: statusCounts.out_for_delivery, color: 'orange' },
          { icon: CheckCircle, label: 'Delivered Today', count: statusCounts.delivered, color: 'green' }
        ].map((stat, index) => (
          <Card key={index} hover className="cursor-pointer">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-500 font-medium">{stat.label}</p>
                <h3 className="text-3xl font-bold text-gray-900 mt-2">{stat.count}</h3>
              </div>
              <div className={`bg-${stat.color}-100 p-3 rounded-lg`}>
                <stat.icon className={`h-8 w-8 text-${stat.color}-600`} />
              </div>
            </div>
          </Card>
        ))}
      </div>

      {/* Delivery Board */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Unassigned */}
        <Card 
          title="Ready to Ship" 
          subtitle={`${deliveries.filter(d => !d.assignedTo).length} orders`}
          headerClassName="bg-yellow-50"
        >
          <div className="space-y-3">
            {deliveries.filter(d => !d.assignedTo).map((delivery) => (
              <div key={delivery.id} className="border border-gray-200 rounded-lg p-4 hover:border-blue-400 transition-colors">
                <div className="flex justify-between items-start mb-3">
                  <div>
                    <p className="font-semibold text-blue-600">{delivery.orderNo}</p>
                    <p className="text-sm text-gray-600 mt-1">{delivery.customer}</p>
                  </div>
                  <Badge variant={getStatusColor(delivery.status)} size="sm">
                    {getStatusLabel(delivery.status)}
                  </Badge>
                </div>
                
                <div className="space-y-2 text-sm text-gray-600">
                  <p className="flex items-center">
                    <MapPin className="h-4 w-4 mr-2" />
                    {delivery.address}
                  </p>
                  <p className="flex items-center">
                    <Package className="h-4 w-4 mr-2" />
                    {delivery.phone}
                  </p>
                </div>

                <Button 
                  size="sm" 
                  fullWidth 
                  className="mt-3"
                  onClick={() => {
                    setSelectedDelivery(delivery);
                    setShowAssignModal(true);
                  }}
                >
                  Assign Delivery Person
                </Button>
              </div>
            ))}
          </div>
        </Card>

        {/* Out for Delivery */}
        <Card 
          title="Out for Delivery" 
          subtitle={`${deliveries.filter(d => d.status === 'out_for_delivery').length} active`}
          headerClassName="bg-orange-50"
        >
          <div className="space-y-3">
            {deliveries.filter(d => d.status === 'out_for_delivery').map((delivery) => (
              <div key={delivery.id} className="border border-orange-200 rounded-lg p-4 bg-orange-50">
                <div className="flex justify-between items-start mb-3">
                  <div>
                    <p className="font-semibold text-blue-600">{delivery.orderNo}</p>
                    <p className="text-sm text-gray-600 mt-1">{delivery.customer}</p>
                  </div>
                  <Badge variant="warning" size="sm">
                    In Transit
                  </Badge>
                </div>
                
                <div className="space-y-2 text-sm text-gray-600">
                  <p className="flex items-center">
                    <User className="h-4 w-4 mr-2" />
                    {delivery.assignedTo}
                  </p>
                  <p className="flex items-center">
                    <MapPin className="h-4 w-4 mr-2" />
                    {delivery.address}
                  </p>
                </div>

                <div className="grid grid-cols-2 gap-2 mt-3">
                  <Button 
                    size="sm" 
                    variant="outline"
                    onClick={() => {
                      setSelectedDelivery(delivery);
                      setShowTimelineModal(true);
                    }}
                  >
                    Track
                  </Button>
                  <Button 
                    size="sm"
                    onClick={() => {
                      setSelectedDelivery(delivery);
                      setShowOtpModal(true);
                    }}
                  >
                    Verify OTP
                  </Button>
                </div>
              </div>
            ))}
          </div>
        </Card>

        {/* Delivered */}
        <Card 
          title="Delivered Today" 
          subtitle={`${deliveries.filter(d => d.status === 'delivered').length} completed`}
          headerClassName="bg-green-50"
        >
          <div className="space-y-3">
            {deliveries.filter(d => d.status === 'delivered').map((delivery) => (
              <div key={delivery.id} className="border border-green-200 rounded-lg p-4 bg-green-50">
                <div className="flex justify-between items-start mb-3">
                  <div>
                    <p className="font-semibold text-blue-600">{delivery.orderNo}</p>
                    <p className="text-sm text-gray-600 mt-1">{delivery.customer}</p>
                  </div>
                  <CheckCircle className="h-6 w-6 text-green-600" />
                </div>
                
                <div className="space-y-2 text-sm text-gray-600">
                  <p className="flex items-center">
                    <User className="h-4 w-4 mr-2" />
                    Delivered by {delivery.assignedTo}
                  </p>
                  <p className="flex items-center">
                    <Clock className="h-4 w-4 mr-2" />
                    {delivery.date}
                  </p>
                </div>
              </div>
            ))}
          </div>
        </Card>
      </div>

      {/* Assign Modal */}
      <Modal
        isOpen={showAssignModal}
        onClose={() => setShowAssignModal(false)}
        title="Assign Delivery Person"
        size="md"
        footer={
          <>
            <Button variant="ghost" onClick={() => setShowAssignModal(false)}>
              Cancel
            </Button>
            <Button>Assign & Notify</Button>
          </>
        }
      >
        {selectedDelivery && (
          <div className="space-y-4">
            <div className="bg-gray-50 rounded-lg p-4">
              <p className="text-sm text-gray-500">Order Number</p>
              <p className="font-semibold text-gray-900">{selectedDelivery.orderNo}</p>
              <p className="text-sm text-gray-600 mt-2">{selectedDelivery.customer}</p>
              <p className="text-sm text-gray-600">{selectedDelivery.address}</p>
            </div>

            <Select
              label="Select Delivery Person"
              options={[
                { value: '1', label: 'Vikram Singh (5 active deliveries)' },
                { value: '2', label: 'Rahul Verma (3 active deliveries)' },
                { value: '3', label: 'Suresh Kumar (Available)' }
              ]}
              required
              placeholder="Choose delivery person"
            />

            <div className="bg-blue-50 border border-blue-200 rounded p-3 text-sm text-blue-800">
              <strong>Note:</strong> Customer will receive SMS with delivery person details and OTP.
            </div>
          </div>
        )}
      </Modal>

      {/* OTP Verification Modal */}
      <Modal
        isOpen={showOtpModal}
        onClose={() => setShowOtpModal(false)}
        title="Verify Delivery OTP"
        size="sm"
      >
        {selectedDelivery && (
          <div className="space-y-4">
            <div className="text-center">
              <div className="bg-blue-100 rounded-full w-16 h-16 flex items-center justify-center mx-auto mb-4">
                <Package className="h-8 w-8 text-blue-600" />
              </div>
              <p className="font-semibold text-gray-900">{selectedDelivery.orderNo}</p>
              <p className="text-sm text-gray-600">{selectedDelivery.customer}</p>
            </div>

            <Input
              label="Enter 6-digit OTP"
              placeholder="000000"
              maxLength={6}
              className="text-center text-2xl tracking-widest"
            />

            <div className="text-center text-sm text-gray-500">
              OTP sent to customer's phone: {selectedDelivery.phone}
            </div>

            <Button fullWidth onClick={() => setShowOtpModal(false)}>
              Verify & Mark Delivered
            </Button>
          </div>
        )}
      </Modal>

      {/* Timeline Modal */}
      <Modal
        isOpen={showTimelineModal}
        onClose={() => setShowTimelineModal(false)}
        title="Delivery Timeline"
        size="md"
      >
        {selectedDelivery && (
          <div className="space-y-4">
            <div className="bg-gray-50 rounded-lg p-4 mb-6">
              <p className="font-semibold text-gray-900">{selectedDelivery.orderNo}</p>
              <p className="text-sm text-gray-600">{selectedDelivery.customer}</p>
            </div>

            <div className="relative">
              {[
                { status: 'Order Received', time: '10:30 AM', completed: true },
                { status: 'Processing', time: '11:00 AM', completed: true },
                { status: 'Ready to Ship', time: '01:00 PM', completed: true },
                { status: 'Out for Delivery', time: '02:30 PM', completed: true },
                { status: 'Delivered', time: 'Pending', completed: false }
              ].map((event, index) => (
                <div key={index} className="flex items-start mb-6 last:mb-0">
                  <div className={`flex-shrink-0 w-8 h-8 rounded-full flex items-center justify-center ${
                    event.completed ? 'bg-green-500' : 'bg-gray-300'
                  }`}>
                    {event.completed ? (
                      <CheckCircle className="h-5 w-5 text-white" />
                    ) : (
                      <div className="w-3 h-3 bg-white rounded-full"></div>
                    )}
                  </div>
                  {index < 4 && (
                    <div className={`absolute left-4 w-0.5 h-12 ${
                      event.completed ? 'bg-green-500' : 'bg-gray-300'
                    }`} style={{ top: `${index * 96 + 32}px` }}></div>
                  )}
                  <div className="ml-4">
                    <p className="font-medium text-gray-900">{event.status}</p>
                    <p className="text-sm text-gray-500">{event.time}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}
      </Modal>
    </div>
  );
};

export default Delivery;