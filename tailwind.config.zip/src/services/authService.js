import { apiService } from './api';
import { STORAGE_KEYS } from '../utils/constants';

export const authService = {
  // Login
  login: async (username, password) => {
    const response = await apiService.post('/auth/login', {
      username,
      password
    });

    const { token, refreshToken, user } = response;

    // Store tokens and user data
    localStorage.setItem(STORAGE_KEYS.AUTH_TOKEN, token);
    localStorage.setItem(STORAGE_KEYS.REFRESH_TOKEN, refreshToken);
    localStorage.setItem(STORAGE_KEYS.USER_DATA, JSON.stringify(user));

    return response;
  },

  // Logout
  logout: () => {
    localStorage.removeItem(STORAGE_KEYS.AUTH_TOKEN);
    localStorage.removeItem(STORAGE_KEYS.REFRESH_TOKEN);
    localStorage.removeItem(STORAGE_KEYS.USER_DATA);
    window.location.href = '/login';
  },

  // Get current user
  getCurrentUser: () => {
    const userData = localStorage.getItem(STORAGE_KEYS.USER_DATA);
    return userData ? JSON.parse(userData) : null;
  },

  // Check if user is authenticated
  isAuthenticated: () => {
    return !!localStorage.getItem(STORAGE_KEYS.AUTH_TOKEN);
  },

  // Refresh token
  refreshToken: async () => {
    const refreshToken = localStorage.getItem(STORAGE_KEYS.REFRESH_TOKEN);
    const response = await apiService.post('/auth/refresh', {
      refreshToken
    });

    const { token } = response;
    localStorage.setItem(STORAGE_KEYS.AUTH_TOKEN, token);

    return response;
  },

  // Change password
  changePassword: async (oldPassword, newPassword) => {
    return apiService.post('/auth/change-password', {
      oldPassword,
      newPassword
    });
  },

  // Check user permissions
  hasPermission: (permission) => {
    const user = authService.getCurrentUser();
    if (!user || !user.permissions) return false;
    return user.permissions.includes(permission);
  },

  // Check if user has any of the permissions
  hasAnyPermission: (permissions) => {
    const user = authService.getCurrentUser();
    if (!user || !user.permissions) return false;
    return permissions.some(permission => user.permissions.includes(permission));
  },

  // Check if user has all permissions
  hasAllPermissions: (permissions) => {
    const user = authService.getCurrentUser();
    if (!user || !user.permissions) return false;
    return permissions.every(permission => user.permissions.includes(permission));
  }
};

export default authService;