import { apiService } from './api';

export const salesService = {
  // Get all sales with filters
  getAllSales: async (params = {}) => {
    return apiService.get('/sales', { params });
  },

  // Get single sale by ID
  getSaleById: async (id) => {
    return apiService.get(`/sales/${id}`);
  },

  // Create new sale (draft/proforma/invoice)
  createSale: async (saleData) => {
    return apiService.post('/sales', saleData);
  },

  // Update sale (only draft/proforma)
  updateSale: async (id, saleData) => {
    return apiService.put(`/sales/${id}`, saleData);
  },

  // Confirm sale (convert to invoice)
  confirmSale: async (id) => {
    return apiService.post(`/sales/${id}/confirm`);
  },

  // Delete sale (only draft)
  deleteSale: async (id) => {
    return apiService.delete(`/sales/${id}`);
  },

  // Get sale PDF
  getSalePDF: async (id) => {
    return apiService.get(`/sales/${id}/pdf`, {
      responseType: 'blob'
    });
  },

  // Add payment
  addPayment: async (saleId, paymentData) => {
    return apiService.post(`/sales/${saleId}/payments`, paymentData);
  },

  // Get payments for a sale
  getPayments: async (saleId) => {
    return apiService.get(`/sales/${saleId}/payments`);
  },

  // Get sales log (audit trail)
  getSalesLog: async (params = {}) => {
    return apiService.get('/sales-log', { params });
  },

  // Get draft by customer phone
  getDraftByPhone: async (phone) => {
    return apiService.get('/sales/draft', { params: { phone } });
  },

  // Convert proforma to invoice
  convertToInvoice: async (id) => {
    return apiService.post(`/sales/${id}/convert-to-invoice`);
  },

  // Cancel sale
  cancelSale: async (id, reason) => {
    return apiService.post(`/sales/${id}/cancel`, { reason });
  }
};

export default salesService;