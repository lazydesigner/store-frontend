import { apiService } from './api';
import { STORAGE_KEYS } from '../utils/constants';

export const authService = {
  // Login
  login: async (username, password) => {
  //   const response = { 
  //     "success": true,
  //     "message": "Login successful",
  //     "user": {
  //         "id": "1",
  //         "name": "Admin User",
  //         "username": "admin",
  //         "email": "admin@store.com",
  //         "phone": "9876543210",
  //         "role": "Admin",
  //         "permissions": [
  //       'SALES_CREATE', 'SALES_VIEW', 'SALES_EDIT', 'SALES_DISCOUNT',
  //   'CUSTOMER_CREATE', 'CUSTOMER_VIEW', 'CUSTOMER_EDIT',
  //   'PRODUCT_VIEW', 'PRODUCT_EDIT',
  //   'INVENTORY_VIEW', 'INVENTORY_ADJUST',
  //   'DELIVERY_VIEW', 'DELIVERY_ASSIGN', 'DELIVERY_UPDATE',
  //   'EMPLOYEE_VIEW',
  //   'REPORTS_VIEW', 'REPORTS_SALES', 'REPORTS_STOCK', 'REPORTS_KITTY', 'REPORTS_GST',
  //   'PAYMENTS_CREATE', 'PAYMENTS_VIEW',
  //   'SETTINGS_VIEW', 'SETTINGS_EDIT'
  //     ],
  //         "isActive": true
  //       },
  //     "data": {
  //       "token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...",
  //       "refreshToken": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...",
        
  // }};
    const response = await apiService.post('/auth/login', {
      username,
      password
    }); 

    const { accessToken, refreshToken, user } = response;

    // Store tokens and user data
    localStorage.setItem(STORAGE_KEYS.AUTH_TOKEN, accessToken);
    localStorage.setItem(STORAGE_KEYS.REFRESH_TOKEN, refreshToken);
    localStorage.setItem(STORAGE_KEYS.USER_DATA, JSON.stringify(user));

    return response;

  },

  // Logout
  logout: () => {
    localStorage.removeItem(STORAGE_KEYS.AUTH_TOKEN);
    localStorage.removeItem(STORAGE_KEYS.REFRESH_TOKEN);
    localStorage.removeItem(STORAGE_KEYS.USER_DATA);
    window.location.href = '/login';
  },

  // Get current user
  getCurrentUser: () => {
    const userData = localStorage.getItem(STORAGE_KEYS.USER_DATA);
    return userData ? JSON.parse(userData) : null; 
  },

  // Check if user is authenticated
  isAuthenticated: () => {
    return !!localStorage.getItem(STORAGE_KEYS.AUTH_TOKEN);
  },

  // Refresh token
  refreshToken: async () => {
    const refreshToken = localStorage.getItem(STORAGE_KEYS.REFRESH_TOKEN);
    const response = await apiService.post('/auth/refresh', {
      refreshToken
    });

    const { accessToken } = response;
    localStorage.setItem(STORAGE_KEYS.AUTH_TOKEN, accessToken);

    return response;
  },

  // Change password
  changePassword: async (oldPassword, newPassword) => {
    return apiService.post('/auth/change-password', {
      oldPassword,
      newPassword
    });
  },

  // Check user permissions
  hasPermission: (permission) => {
    const user = authService.getCurrentUser();
    if (!user || !user.permissions) return false;
    return user.permissions.includes(permission);
  },

  // Check if user has any of the permissions
  hasAnyPermission: (permissions) => {
    const user = authService.getCurrentUser();
    if (!user || !user.permissions) return false;
    return permissions.some(permission => user.permissions.includes(permission));
  },

  // Check if user has all permissions
  hasAllPermissions: (permissions) => {
    const user = authService.getCurrentUser();
    if (!user || !user.permissions) return false;
    return permissions.every(permission => user.permissions.includes(permission));
  }
};

export default authService;