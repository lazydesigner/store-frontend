import React, { useState, useEffect } from 'react';
import Input from '../common/Input';
import Select from '../common/Select';
import Button from '../common/Button';
import { validators, validateForm } from '../../utils/validators';
import { useNotification } from '../../context/NotificationContext';
import roleService from '../../services/roleService';

function convertToRoleOptions(roles) {
  return roles.map(role => ({
    value: String(role.id),   // convert id to string
    label: role.name
  }));
}

const EmployeeForm = ({ roles= [], employee = null, onSubmit, onCancel }) => {
  const { success, error } = useNotification();
  const [formData, setFormData] = useState({ 
    name: employee?.name || '',
    username: employee?.username || '',
    phone: employee?.phone || '',
    email: employee?.email || '',
    password: '',
    confirmPassword: '',
    role_ids: employee?.roleId || '',
    is_active: employee?.isActive ?? true
  });  

  const [errors, setErrors] = useState({});
  const [loading, setLoading] = useState(false);

  const handleChange = (e) => {
    const { name, value, type, checked } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: type === 'checkbox' ? checked : value
    }));

    if (errors[name]) {
      setErrors(prev => ({ ...prev, [name]: '' }));
    }
  };

  const validate = () => {
    const rules = {
      name: [(v) => validators.required(v, 'Employee name')],
      username: [validators.username],
      phone: [validators.phone],
      email: [validators.email],
      role_ids: [(v) => validators.required(v, 'Role')]
    };

    // Only validate password for new employees
    if (!employee) {
      rules.password = [validators.password];
      rules.confirmPassword = [(v) => validators.required(v, 'Confirm password')];
    } else if (formData.password) {
      rules.password = [validators.password];
      rules.confirmPassword = [(v) => validators.required(v, 'Confirm password')];
    }

    const { isValid, errors: validationErrors } = validateForm(formData, rules);

    // Check password match
    if (formData.password && formData.password !== formData.confirmPassword) {
      validationErrors.confirmPassword = 'Passwords do not match';
    }

    setErrors(validationErrors); 
    return Object.keys(validationErrors).length === 0;
  };

  const handleSubmit = async (e) => {
    e.preventDefault(); 

    if (!validate()) return; 

    setLoading(true);
    try {

      let dataToSubmit = {}

      if(employee?.id){ 
        dataToSubmit = { 
          ...formData, 
          id: employee?.id || null 
        };
      }else{
        dataToSubmit = { ...formData };
      }

      
      delete dataToSubmit.confirmPassword;

      // Don't send password if not changed (for updates)
      if (employee && !formData.password) {
        delete dataToSubmit.password;
      } 

      await onSubmit(dataToSubmit);
    } catch (error) {
      console.error('Form submission error:', error); 
    } finally {
      setLoading(false); 
    }
  };

  const roleOptions =   convertToRoleOptions(roles); 


  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <Input
          label="Full Name"
          name="name"
          value={formData.name}
          onChange={handleChange}
          placeholder="Enter full name"
          error={errors.name}
          required
        />

        <Input
          label="Username"
          name="username"
          value={formData.username}
          onChange={handleChange}
          placeholder="username"
          error={errors.username}
          required
          disabled={!!employee}
        />

        <Input
          label="Phone Number"
          name="phone"
          value={formData.phone}
          onChange={handleChange}
          placeholder="10-digit mobile"
          error={errors.phone}
          required
        />

        <Input
          label="Email"
          name="email"
          type="email"
          value={formData.email}
          onChange={handleChange}
          placeholder="employee@email.com"
          error={errors.email}
        />

        <Input
          label={employee ? "New Password (leave blank to keep current)" : "Password"}
          name="password"
          type="password"
          value={formData.password}
          onChange={handleChange}
          placeholder="Min 8 characters"
          error={errors.password}
          required={!employee}
        />

        <Input
          label="Confirm Password"
          name="confirmPassword"
          type="password"
          value={formData.confirmPassword}
          onChange={handleChange}
          placeholder="Re-enter password"
          error={errors.confirmPassword}
          required={!employee || !!formData.password}
        />

        <Select
          label="Role"
          name="role_ids"
          value={formData.role_ids}
          onChange={handleChange}
          options={roleOptions}
          error={errors.role_ids}
          required
          className="md:col-span-2"
        />
      </div>

      <div className="pt-4 border-t">
        <label className="flex items-center space-x-2">
          <input
            type="checkbox"
            name="is_active"
            checked={formData.is_active}
            onChange={handleChange}
            className="rounded"
          />
          <span className="text-sm text-gray-700">Mark as active</span>
        </label>
      </div>
      <div className="pt-4 text-xs text-red-500">
        <ul className='list-disc ml-4'>
          <li>Phone Number Must be unique</li>
          <li>Username Must be unique</li> 
        </ul>
      </div>

      <div className="flex justify-end space-x-3 pt-4 border-t">
        <Button type="button" variant="ghost" onClick={onCancel}>
          Cancel
        </Button>
        <Button type="submit" loading={loading}>
          {employee ? 'Update Employee' : 'Create Employee'}
        </Button>
      </div>
    </form>
  );
};

export default EmployeeForm;