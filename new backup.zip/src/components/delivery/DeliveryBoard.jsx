import React from 'react';
import DeliveryCard from './DeliveryCard';
import Card from '../common/Card';

const DeliveryBoard = ({ 
  deliveries = {}, 
  onAssign,
  onMarkReadyToShip,
  onMarkOutForDelivery,
  onTrack, 
  onVerifyOTP,
  onResendOTP
}) => {
  const { readyToShip = [], outForDelivery = [], delivered = [] } = deliveries;

  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
      {/* Ready to Ship (includes new, processing, ready_to_ship) */}
      <Card 
        title="Ready to Ship" 
        subtitle={`${readyToShip.length} orders`}
        headerClassName="bg-yellow-50"
      >
        <div className="space-y-3">
          {readyToShip.length === 0 ? (
            <p className="text-center text-gray-500 py-8">No pending deliveries</p>
          ) : (
            readyToShip.map((delivery) => (
              <DeliveryCard
                key={delivery.id}
                delivery={delivery}
                onAssign={onAssign}
                onMarkReadyToShip={onMarkReadyToShip}
                onMarkOutForDelivery={onMarkOutForDelivery}
                onTrack={onTrack}
                onVerifyOTP={onVerifyOTP}
                onResendOTP={onResendOTP}
              />
            ))
          )}
        </div>
      </Card>

      {/* Out for Delivery */}
      <Card 
        title="Out for Delivery" 
        subtitle={`${outForDelivery.length} active`}
        headerClassName="bg-orange-50"
      >
        <div className="space-y-3">
          {outForDelivery.length === 0 ? (
            <p className="text-center text-gray-500 py-8">No active deliveries</p>
          ) : (
            outForDelivery.map((delivery) => (
              <DeliveryCard
                key={delivery.id}
                delivery={delivery}
                onAssign={onAssign}
                onMarkReadyToShip={onMarkReadyToShip}
                onMarkOutForDelivery={onMarkOutForDelivery}
                onTrack={onTrack}
                onVerifyOTP={onVerifyOTP}
                onResendOTP={onResendOTP}
              />
            ))
          )}
        </div>
      </Card>

      {/* Delivered */}
      <Card 
        title="Delivered Today" 
        subtitle={`${delivered.length} completed`}
        headerClassName="bg-green-50"
      >
        <div className="space-y-3">
          {delivered.length === 0 ? (
            <p className="text-center text-gray-500 py-8">No deliveries today</p>
          ) : (
            delivered.map((delivery) => (
              <DeliveryCard
                key={delivery.id}
                delivery={delivery}
                onAssign={onAssign}
                onMarkReadyToShip={onMarkReadyToShip}
                onMarkOutForDelivery={onMarkOutForDelivery}
                onTrack={onTrack}
                onVerifyOTP={onVerifyOTP}
                onResendOTP={onResendOTP}
              />
            ))
          )}
        </div>
      </Card>
    </div>
  );
};

export default DeliveryBoard;