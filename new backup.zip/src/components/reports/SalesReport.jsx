import React from 'react'; 
import { TrendingUp, DollarSign, ShoppingCart } from 'lucide-react';
import Card from '../common/Card';
import Button from '../common/Button';

const SalesReport = ({ data = {}, dateRange }) => {
  const {
    totalRevenue = 0,
    totalOrders = 0,
    averageOrderValue = 0,
    growth = 0,
    salesByEmployee = [],
    salesByProduct = []
  } = data;

  return (
    <div className="space-y-6">
      {/* Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <Card>
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-500 mb-1">Total Revenue</p>
              <h3 className="text-2xl font-bold text-green-600">
                ₹{totalRevenue.toLocaleString()}
              </h3>
              {/* <p className="text-sm text-green-600 mt-1">
                <TrendingUp className="h-4 w-4 inline mr-1" />
                +{growth}% from last period
              </p> */}
            </div>
            <div className="bg-green-100 p-3 rounded-lg">
              <DollarSign className="h-6 w-6 text-green-600" />
            </div>
          </div>
        </Card>

        <Card>
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-500 mb-1">Total Orders</p>
              <h3 className="text-2xl font-bold text-blue-600">{totalOrders}</h3>
              <p className="text-sm text-blue-600 mt-1">This period</p>
            </div>
            <div className="bg-blue-100 p-3 rounded-lg">
              <ShoppingCart className="h-6 w-6 text-blue-600" />
            </div>
          </div>
        </Card>

        <Card>
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-500 mb-1">Avg Order Value</p>
              <h3 className="text-2xl font-bold text-purple-600">
                ₹{averageOrderValue.toLocaleString()}
              </h3>
              <p className="text-sm text-purple-600 mt-1">Per order</p>
            </div>
            <div className="bg-purple-100 p-3 rounded-lg">
              <TrendingUp className="h-6 w-6 text-purple-600" />
            </div>
          </div>
        </Card>
      </div>

      {/* Sales by Employee */}
      <Card 
        title="Sales by Employee" 
        headerActions={<Button size="sm" variant="outline">Export</Button>}
      >
        <div className="overflow-x-auto">
          <table className="min-w-full">
            <thead className="bg-gray-50">
              <tr>
                <th className="px-6 py-3 text-left text-xs font-semibold text-gray-600 uppercase">Employee</th>
                <th className="px-6 py-3 text-left text-xs font-semibold text-gray-600 uppercase">Orders</th>
                <th className="px-6 py-3 text-left text-xs font-semibold text-gray-600 uppercase">Revenue</th>
                <th className="px-6 py-3 text-left text-xs font-semibold text-gray-600 uppercase">Commission</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-200">
              {salesByEmployee.map((emp, index) => (
                <tr key={index} className="hover:bg-gray-50">
                  <td className="px-6 py-4 text-sm font-medium text-gray-900">{emp.name}</td>
                  <td className="px-6 py-4 text-sm text-gray-600">{emp.orders}</td>
                  <td className="px-6 py-4 text-sm font-semibold text-green-600">
                    ₹{emp.revenue.toLocaleString()}
                  </td>
                  <td className="px-6 py-4 text-sm font-semibold text-purple-600">
                    ₹{emp.commission.toLocaleString()}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </Card>

      {/* Sales by Product */}
      <Card 
        title="Top Selling Products"
        headerActions={<Button size="sm" variant="outline">View All</Button>}
      >
        <div className="space-y-3">
          {salesByProduct.map((product, index) => (
            <div key={index} className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
              <div className="flex items-center space-x-4">
                <div className="bg-blue-100 rounded-full w-10 h-10 flex items-center justify-center">
                  <span className="font-bold text-blue-600">#{index + 1}</span>
                </div>
                <div>
                  <p className="font-medium text-gray-900">{product.name}</p>
                  <p className="text-sm text-gray-500">{product.sold} units sold</p>
                </div>
              </div>
              <div className="text-right">
                <p className="font-semibold text-gray-900">₹{product.revenue.toLocaleString()}</p>
                <p className="text-sm text-gray-500">{product.percentage}% of total</p>
              </div>
            </div>
          ))}
        </div>
      </Card>
    </div>
  );
};

export default SalesReport;