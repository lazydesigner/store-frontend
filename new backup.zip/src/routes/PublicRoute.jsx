import React from 'react';
import { Navigate } from 'react-router-dom';
import { useAuthContext } from '../context/AuthContext';
import Loader from '../components/common/Loader';

const PublicRoute = ({ children, redirectIfAuthenticated = true }) => {
  const { isAuthenticated, loading } = useAuthContext();

  if (loading) {
    return <Loader fullScreen message="Loading..." />;
  }

  if (isAuthenticated && redirectIfAuthenticated) {
    return <Navigate to="/dashboard" replace />;
  }

  return children;
};

export default PublicRoute;