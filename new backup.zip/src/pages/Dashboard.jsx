import React, { useState, useEffect } from 'react';
import { TrendingUp, ShoppingCart, Users, Package } from 'lucide-react';
import DashboardStats from '../components/dashboard/DashboardStats';
import SalesChart from '../components/dashboard/SalesChart';
import RecentOrders from '../components/dashboard/RecentOrders';
import LowStockAlert from '../components/dashboard/LowStockAlert';
import KittyLeaderboard from '../components/dashboard/KittyLeaderboard';
import { useNotification } from '../context/NotificationContext';

import { dashboardService } from '../services/dashboardService';
import {reportService} from '../services/reportService';


const Dashboard = () => {
  const { success } = useNotification();
  const [loading, setLoading] = useState(true);
  const [dStats, setDStats] = useState([]);
  const [salesChartData, setSalesChartData] = useState([]);
  const [topSellers, setTopSellers] = useState([]);
  const [recentOrders, setRecentOrders] = useState([]);
  const [lowStockItems, setLowStockItems] = useState([]);

  useEffect(() => {
    // Simulate data loading
    LoadData()
    setTimeout(() => {
      setLoading(false);
      success('Dashboard loaded successfully');
    }, 500);
  }, []);

  const LoadData = async () => {
    const [DashboardStats, getKittyDashboard, getRecentSale, getSaleChart, stockReportData] = await Promise.all([
      dashboardService.getDashboardStats(),
      dashboardService.getKittyDashboard(),
      dashboardService.getRecentSale(),
      dashboardService.getSaleChart(), 
      dashboardService.getLowStock(),
    ])
    setDStats(DashboardStats.data.stats) 

    setLowStockItems(stockReportData.data.map((low)=>(
      { 
        name: low.product.name, 
        sku: low.product.sku, 
        stock: low.quantity, 
        minStock: low.reorder_level, 
        warehouse: low.warehouse.name }
    ))) 

    setRecentOrders(getRecentSale.data.slice(0, 10).map((sale) => (
      {
        id: sale.number,
        customer: sale.customer.name,
        amount: '₹' + sale.subtotal,
        status: sale.status,
        date: new Date(sale.created_at).toLocaleString('en-IN', {
          year: 'numeric',
          month: '2-digit',
          day: '2-digit',
          hour: '2-digit',
          minute: '2-digit'
        })
      })))

    setTopSellers(getKittyDashboard.data.map((kitty) => ({
      name: kitty.employee_name,
      sales: '₹' + kitty.total_amount,
      orders: kitty.total_sales,
      commission: '₹' + kitty.total_margin

    })))

    setSalesChartData(getSaleChart.data.chart.map((item) => ({
      label: item.label,
      value: item.value,
      orders: item.orders
    })))
  }  

  const handleViewOrder = (order) => {
    console.log('View order:', order);
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="spinner"></div>
      </div>
    );
  }
 
  const stats = [
    {
      title: 'Total Sales',
      value: dStats[0]?.value,
      change: dStats[0]?.change,
      changeType: dStats[0]?.changeType,
      icon: TrendingUp,
      color: dStats[0]?.color
    },
    {
      title: 'Orders',
      value: dStats[1]?.value,
      change: dStats[1]?.change,
      changeType: dStats[1]?.changeType,
      icon: ShoppingCart,
      color: dStats[1]?.color
    },
    {
      title: 'Customers',
      value: dStats[2]?.value,
      change: dStats[2]?.change,
      changeType: dStats[2]?.changeType,
      icon: Users,
      color: dStats[2]?.color
    },
    {
      title: 'Products',
      value: dStats[3]?.value,
      change: dStats[3]?.change,
      changeType: dStats[3]?.changeType,
      icon: Package,
      color: dStats[3]?.color
    }
  ];

  return (
    <div className="space-y-6">
      {/* Page Header */}
      <div>
        <h1 className="text-3xl font-bold text-gray-900">Dashboard</h1>
        <p className="text-gray-500 mt-1">Welcome back! Here's what's happening today.</p>
      </div>

      {/* Stats Grid */}
      <DashboardStats stats={stats} />

      {/* Charts and Recent Activity */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2">
          <SalesChart data={salesChartData} />
        </div>
        <div>
          <LowStockAlert items={lowStockItems} />
        </div>
      </div>

      {/* Recent Orders */}
      <RecentOrders orders={recentOrders} onView={handleViewOrder} />

      
      {/* Top Sellers Leaderboard */}

      {(JSON.parse(localStorage.getItem('user_data')).roles.includes('Admin') || JSON.parse(localStorage.getItem('user_data')).roles.includes('Manager')) ? (<KittyLeaderboard sellers={topSellers} />) : (<></>)}
      
    </div>
  );
};

export default Dashboard;